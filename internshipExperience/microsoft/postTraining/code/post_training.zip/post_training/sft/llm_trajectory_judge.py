#!/usr/bin/env python
"""
Offline LLM trajectory-quality judge for SFT data selection (design §4f).

A FINAL top-layer filter over generated teacher rollouts: it does not generate
or fix anything, it reads a finished trajectory and returns a structured
imitation-worthiness verdict. Verifier + deterministic gates handle correctness
and hard behaviour; this judge scores the qualitative dimensions they are blind
to (clean code-act, sound reasoning, honesty, convergence).

Only rollouts that already passed the cheap gates (via --scores) are judged, to
save cost. Writes one verdict per rollout to --out (verdicts.jsonl).

Run with the harness venv:
    .venv-harness/bin/python -m post_training.sft.llm_trajectory_judge \
        --results_root search_agent/batch_results/teacher_gen_train \
        --scores search_agent/batch_results/teacher_gen_train/scores.jsonl
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from llm_client import AOAIClient, safe_json_parse  # noqa: E402


_JUDGE_SYSTEM = """\
You are a strict data-quality reviewer selecting agent trajectories to use as
supervised fine-tuning (SFT) demonstrations for a smaller model. The agent runs
a code-act loop: it calls an `execute_python` tool, searches the web, extracts
values, and writes an output table. You are NOT grading whether the final
answer is fully correct (a separate verifier does that). You are grading whether
this trajectory is a GOOD HABIT to imitate.

Score each dimension 1-5 (5 = excellent), citing the turn number for any low score:
1. protocol   - always uses the execute_python tool correctly; never narrates code instead of calling it.
2. code       - idiomatic, minimal, no repeated/near-duplicate cells, no thrashing; extracts values sensibly.
3. reasoning  - the `thought`s are coherent; the plan is sensible (search -> read -> write -> verify -> stop).
4. honesty    - output values are traceable to search results; uses nan when not found; NO invented or constant-filled rows.
5. convergence- searches then writes output and stops; no aimless wandering or budget-blowing.
6. overall    - would a student that copies this trajectory acquire good habits?

Set "hard_fail": true if you see fabrication (invented/constant-filled data) OR
a protocol violation (narrating code instead of calling the tool).

Respond with STRICT JSON only, no prose:
{"scores":{"protocol":N,"code":N,"reasoning":N,"honesty":N,"convergence":N,"overall":N},
 "hard_fail":true|false,
 "reasons":"one short line, cite turns for low scores"}
"""


def _truncate(s: str, n: int) -> str:
    s = s or ""
    return s if len(s) <= n else s[:n] + f"…[+{len(s)-n} chars]"


def _render_trajectory(run_dir: Path, query: str, f1_hint) -> str:
    """Compact, cheap rendering: thought + code + truncated outcome per turn."""
    at = run_dir / "agent_trace.json"
    parts = [f"TASK:\n{_truncate(query, 800)}\n"]
    if f1_hint is not None:
        parts.append(f"(verifier hint: F1_row={f1_hint.get('f1_row')}, F1_item={f1_hint.get('f1_item')})\n")
    conv = []
    if at.exists():
        try:
            conv = json.loads(at.read_text()).get("conversation", [])
        except Exception:
            conv = []
    turn = 0
    pending_code = None
    for m in conv:
        role = m.get("role")
        if role == "assistant" and m.get("tool_calls"):
            turn += 1
            try:
                a = json.loads(m["tool_calls"][0]["function"]["arguments"])
                th = _truncate(a.get("thought", ""), 220)
                code = _truncate(a.get("code", ""), 600)
            except Exception:
                th, code = "", "<unparsable tool args>"
            parts.append(f"\n--- Turn {turn} ---\nthought: {th}\ncode:\n{code}")
            pending_code = True
        elif role == "assistant" and m.get("content"):
            parts.append(f"\nFINAL ANSWER:\n{_truncate(m.get('content'), 700)}")
        elif role == "tool":
            c = m.get("content") or ""
            if "[error]" in c:
                outcome = "ERROR: " + _truncate(c.split("[error]", 1)[-1], 160)
            else:
                outcome = "ok: " + _truncate(c.replace("\n", " "), 160)
            if pending_code:
                parts.append(f"outcome: {outcome}")
                pending_code = False
    # output file head
    outs = glob.glob(str(run_dir / "workspace" / "output" / "*"))
    if outs:
        try:
            head = "\n".join(Path(outs[0]).read_text(encoding="utf-8", errors="ignore").splitlines()[:25])
            parts.append(f"\nOUTPUT FILE ({os.path.basename(outs[0])}) HEAD:\n{_truncate(head, 1200)}")
        except Exception:
            pass
    else:
        parts.append("\nOUTPUT FILE: (none)")
    return "\n".join(parts)


def _passes_cheap_gates(s: dict) -> bool:
    """Only judge rollouts that already cleared the deterministic gates."""
    return (s.get("has_output") and s.get("converged")
            and not s.get("looped") and s.get("err_rate", 1.0) <= 0.30
            and not str(s.get("eval_err") or ""))


def _judge_one(client, iid, trial, run_dir, query, s):
    text = _render_trajectory(Path(run_dir), query, s)
    try:
        resp = client.safe_chat(
            [{"role": "system", "content": _JUDGE_SYSTEM},
             {"role": "user", "content": text}],
        )
        raw = resp.choices[0].message.content or ""
        v = safe_json_parse(raw) or {}
    except Exception as e:  # noqa: BLE001
        return {"instance_id": iid, "trial": trial, "run_dir": run_dir,
                "keep": False, "judge_err": f"{type(e).__name__}: {e}"[:200]}
    sc = v.get("scores", {}) if isinstance(v, dict) else {}
    hard_fail = bool(v.get("hard_fail", False))
    overall = sc.get("overall", 0) or 0
    honesty = sc.get("honesty", 0) or 0
    keep = (not hard_fail) and overall >= 4 and honesty >= 4
    return {"instance_id": iid, "trial": trial, "run_dir": run_dir,
            "scores": sc, "hard_fail": hard_fail, "keep": keep,
            "reasons": v.get("reasons", "")}


def main() -> int:
    ap = argparse.ArgumentParser(description="LLM trajectory-quality judge (SFT selection §4f)")
    ap.add_argument("--results_root", required=True)
    ap.add_argument("--scores", default=None, help="scores.jsonl (to judge only gate-passers + supply F1 hint)")
    ap.add_argument("--widesearch_root", default=os.getenv("WIDESEARCH_ROOT", "/home/dkidna/WideSearch"))
    ap.add_argument("--out", default=None)
    ap.add_argument("--judge_model", default="gpt-4.1")
    ap.add_argument("--max_workers", type=int, default=4)
    ap.add_argument("--limit", type=int, default=0, help="judge at most N (0=all); for a quick smoke test")
    args = ap.parse_args()

    results_root = Path(args.results_root)
    out_path = Path(args.out) if args.out else results_root / "verdicts.jsonl"
    scores_path = Path(args.scores) if args.scores else results_root / "scores.jsonl"

    # Load scores (behavioural gates + F1 hint), keyed by (iid, trial).
    smap = {}
    if scores_path.exists():
        for line in scores_path.read_text().splitlines():
            if line.strip():
                r = json.loads(line)
                smap[(r["instance_id"], r["trial"])] = r
    else:
        print(f"WARNING: no scores at {scores_path}; judging ALL rollouts (no gate prefilter).")

    # Load queries for task text.
    from search_agent.batch_eval import _ensure_widesearch_importable, load_widesearch_queries
    _ensure_widesearch_importable(Path(args.widesearch_root))

    from post_training.sft.score_trajectories import _discover_rollouts
    rollouts = _discover_rollouts(results_root)
    iids = sorted({iid for iid, _, _, _ in rollouts})
    queries = load_widesearch_queries(Path(args.widesearch_root), iids, None)
    q_by_id = {q.instance_id: q.query for q in queries}

    # Build the work list: only gate-passers if scores present.
    work = []
    skipped_gate = 0
    for iid, trial, resp_path, run_dir in rollouts:
        s = smap.get((iid, trial), {})
        if smap and not _passes_cheap_gates(s):
            skipped_gate += 1
            continue
        work.append((iid, trial, str(run_dir), q_by_id.get(iid, ""), s))
    if args.limit:
        work = work[: args.limit]
    print(f"{len(rollouts)} rollouts; {skipped_gate} skipped by cheap gates; judging {len(work)}")

    client = AOAIClient(model=args.judge_model)
    kept = 0
    with out_path.open("w", encoding="utf-8") as fo, \
            ThreadPoolExecutor(max_workers=args.max_workers) as pool:
        futs = [pool.submit(_judge_one, client, iid, trial, run_dir, q, s)
                for iid, trial, run_dir, q, s in work]
        for fut in as_completed(futs):
            r = fut.result()
            kept += 1 if r.get("keep") else 0
            fo.write(json.dumps(r, ensure_ascii=False) + "\n")
            sc = r.get("scores", {})
            print(f"  {r['instance_id']}__t{r['trial']}: keep={r.get('keep')} "
                  f"hard_fail={r.get('hard_fail')} overall={sc.get('overall')} "
                  f"honesty={sc.get('honesty')} :: {_truncate(r.get('reasons',''), 90)}")
    print(f"\nkept {kept}/{len(work)} -> {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
