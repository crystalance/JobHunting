#!/usr/bin/env python
"""
Score generated teacher trajectories for rejection-sampling SFT selection.

For every rollout under --results_root (both {iid}__t{n} multi-sample layout and
the single-sample {iid} layout), compute:
  * verifier score  : F1_row / F1_item / score via the WideSearch evaluator
  * behavioural stats: n_turns, n_searches, error-rate, looped, has_output,
                       converged, constant_fill  (deterministic, from the trace)

Writes one JSON line per rollout to --out (default: <results_root>/scores.jsonl).
This is the input to the selection step (build_sft_data --scores ...).

Run with the harness venv (has the WideSearch eval deps):
    .venv-harness/bin/python -m post_training.sft.score_trajectories \
        --results_root search_agent/batch_results/teacher_gen_train \
        --widesearch_root /home/dkidna/WideSearch
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys
from collections import Counter
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from search_agent.batch_eval import (  # noqa: E402
    _ensure_widesearch_importable,
    _patch_widesearch_eval_client,
    load_widesearch_queries,
)

_RESP_RE = re.compile(r"^(?P<iid>ws_[a-z]+_\d+)(?:__t(?P<trial>\d+))?_response\.jsonl$")


def _discover_rollouts(results_root: Path):
    """Yield (iid, trial, response_path, run_dir) for every rollout present."""
    out = []
    for f in sorted(results_root.glob("*_response.jsonl")):
        m = _RESP_RE.match(f.name)
        if not m:
            continue
        iid = m.group("iid")
        trial = int(m.group("trial")) if m.group("trial") is not None else 0
        run_dir = results_root / f.name[: -len("_response.jsonl")]
        out.append((iid, trial, f, run_dir))
    return out


def _behavioural_stats(run_dir: Path) -> dict:
    """Deterministic behaviour metrics from a rollout's trace + outputs."""
    stats = {
        "n_turns": 0, "n_searches": 0, "n_err_cells": 0, "err_rate": 0.0,
        "looped": False, "has_output": False, "converged": False,
        "constant_fill": False, "answer_len": 0,
    }
    at = run_dir / "agent_trace.json"
    if at.exists():
        try:
            d = json.loads(at.read_text())
        except Exception:
            d = {}
        conv = d.get("conversation", [])
        stats["answer_len"] = len(d.get("answer") or "")
        n_tool_cells = 0
        fail_hashes = Counter()
        code_by_turn = []
        for m in conv:
            if m.get("role") == "assistant" and m.get("tool_calls"):
                stats["n_turns"] += 1
                try:
                    args = json.loads(m["tool_calls"][0]["function"]["arguments"])
                    code_by_turn.append(args.get("code", ""))
                except Exception:
                    code_by_turn.append(None)
            elif m.get("role") == "tool":
                n_tool_cells += 1
                c = m.get("content") or ""
                if "[error]" in c:
                    stats["n_err_cells"] += 1
                    # hash the code of the *preceding* assistant turn (the one
                    # that produced this error) to detect repeated failing cells.
                    if code_by_turn and code_by_turn[-1]:
                        fail_hashes[hash(code_by_turn[-1].strip())] += 1
        if n_tool_cells:
            stats["err_rate"] = round(stats["n_err_cells"] / n_tool_cells, 3)
        stats["looped"] = any(v > 2 for v in fail_hashes.values())
        # converged = finished with a natural text answer (last assistant msg
        # has content and no tool_calls)
        for m in reversed(conv):
            if m.get("role") == "assistant":
                stats["converged"] = bool(m.get("content")) and not m.get("tool_calls")
                break

    sl = glob.glob(str(run_dir / "workspace" / "log" / "*" / "search_log.json"))
    if sl:
        try:
            stats["n_searches"] = len(json.loads(Path(sl[0]).read_text()))
        except Exception:
            pass

    outs = glob.glob(str(run_dir / "workspace" / "output" / "*"))
    stats["has_output"] = len(outs) > 0
    if outs:
        stats["constant_fill"] = _detect_constant_fill(outs[0])
    return stats


def _detect_constant_fill(path: str) -> bool:
    """Heuristic: a non-empty/non-nan value repeated across most rows of a
    column => likely fabricated constant-fill (e.g. same net worth every year)."""
    try:
        txt = Path(path).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return False
    rows = []
    for line in txt.splitlines():
        line = line.strip()
        if not line or set(line) <= {"|", "-", " ", ":"}:
            continue
        cells = [c.strip() for c in re.split(r"\||,", line)]
        cells = [c for c in cells if c != ""]
        if cells:
            rows.append(cells)
    if len(rows) < 5:
        return False
    body = rows[1:]  # skip header
    ncol = max((len(r) for r in body), default=0)
    for c in range(ncol):
        col = [r[c] for r in body if len(r) > c]
        vals = [v for v in col if v.lower() not in ("nan", "n/a", "-", "")]
        if len(vals) >= 5:
            top, cnt = Counter(vals).most_common(1)[0]
            if cnt / len(vals) > 0.6:
                return True
    return False


def main() -> int:
    ap = argparse.ArgumentParser(description="Score teacher rollouts for SFT selection")
    ap.add_argument("--results_root", required=True)
    ap.add_argument("--widesearch_root", default=os.getenv("WIDESEARCH_ROOT", "/home/dkidna/WideSearch"))
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    results_root = Path(args.results_root)
    out_path = Path(args.out) if args.out else results_root / "scores.jsonl"

    _ensure_widesearch_importable(Path(args.widesearch_root))
    _patch_widesearch_eval_client()
    from src.evaluation.data_loader import WideSearchResponseLoader
    from src.evaluation.evaluation import evaluate_single_query

    rollouts = _discover_rollouts(results_root)
    iids = sorted({iid for iid, _, _, _ in rollouts})
    queries = load_widesearch_queries(Path(args.widesearch_root), iids, None)
    q_by_id = {q.instance_id: q for q in queries}
    print(f"discovered {len(rollouts)} rollouts across {len(iids)} instances")

    tmp_csv = results_root / "_tmp_eval.csv"
    n_written = 0
    with out_path.open("w", encoding="utf-8") as fo:
        for iid, trial, resp_path, run_dir in rollouts:
            rec = {"instance_id": iid, "trial": trial,
                   "run_dir": str(run_dir), "response_path": str(resp_path)}
            rec.update(_behavioural_stats(run_dir))
            # verifier score
            f1_row = f1_item = score = 0.0
            err = None
            q = q_by_id.get(iid)
            try:
                resp_list = WideSearchResponseLoader.load_response(str(resp_path))
                resp = resp_list[0] if resp_list else None
                if q is not None and resp is not None and not resp.response.startswith("ERROR:"):
                    ev = evaluate_single_query(q, resp, str(tmp_csv))
                    f1_row, f1_item, score = ev.f1_by_row, ev.f1_by_item, ev.score
                elif resp is None or (resp and resp.response.startswith("ERROR:")):
                    err = "error_or_empty_response"
            except Exception as e:  # noqa: BLE001
                err = f"{type(e).__name__}: {e}"[:200]
            rec.update({"f1_row": round(f1_row, 4), "f1_item": round(f1_item, 4),
                        "score": round(score, 4), "eval_err": err})
            fo.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n_written += 1
            print(f"  {iid}__t{trial}: f1_row={f1_row:.2f} f1_item={f1_item:.2f} "
                  f"turns={rec['n_turns']} search={rec['n_searches']} "
                  f"err_rate={rec['err_rate']} loop={rec['looped']} "
                  f"out={rec['has_output']} conv={rec['converged']} "
                  f"cfill={rec['constant_fill']}")
    if tmp_csv.exists():
        tmp_csv.unlink()
    print(f"\nwrote {n_written} rows -> {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
