"""
verl multi-turn tool: `execute_python` for GRPO training of the WideSearch agent.

Wraps the SAME `PythonExecutor` (persistent IPython kernel) + `search_client`
(Bing + gpt-4.1-mini) used by the SFT harness, so the RL rollout environment is
byte-identical to what SFT/eval used. One kernel per rollout (per tool instance).

The tool ONLY runs code and returns stdout — it computes NO reward. Reward is
outcome-level and handled by post_training/grpo/widesearch_reward.py (scores the
final answer table vs gold). This keeps the tool simple and the reward
self-contained.

Registered in tools.yaml as:
  class_name: post_training.grpo.execute_python_tool.ExecutePythonTool
"""
from __future__ import annotations

import asyncio
import os
import shutil
import sys
import tempfile
from typing import Any, Optional
from uuid import uuid4

# Make the harness importable (repo root = .../WebSearchResearch)
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from verl.tools.base_tool import BaseTool
from verl.tools.schemas import OpenAIFunctionToolSchema, ToolResponse
from verl.utils.rollout_trace import rollout_trace_op

from python_executor import PythonExecutor
from search_agent.search_agent import _format_exec_result

_TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "execute_python",
        "description": (
            "Execute Python code in a persistent IPython kernel. The kernel has a "
            "pre-loaded `search_client` (with a `.search(query)` method) and a "
            "`WORKSPACE` path. Read from input/, write results to output/."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "thought": {"type": "string", "description": "Your reasoning before the code."},
                "code": {"type": "string", "description": "The Python code to execute."},
            },
            "required": ["thought", "code"],
        },
    },
}


def _bootstrap_code(project_root: str, workspace: str, search_model: str,
                    log_dir: str) -> str:
    """Kernel setup: inject WORKSPACE + an Azure gpt-4.1-mini search_client.
    Mirrors SearchAgent._bootstrap_kernel (Azure search path)."""
    # Propagate SEARCH_* knobs (cache dir, budgets, throttles) into the kernel
    # subprocess explicitly, so they survive ray/subprocess env quirks. Paths
    # are made absolute because the kernel os.chdir()s into WORKSPACE.
    search_env = {}
    for k, v in os.environ.items():
        if k.startswith("SEARCH_"):
            if k == "SEARCH_CACHE_DIR" and v:
                v = os.path.abspath(v)
            search_env[k] = v
    return f"""\
import sys, os
for _k, _v in {search_env!r}.items():
    os.environ[_k] = _v
_project_root = {project_root!r}
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)
WORKSPACE = {workspace!r}
os.makedirs(os.path.join(WORKSPACE, 'output'), exist_ok=True)
os.makedirs(os.path.join(WORKSPACE, 'input'), exist_ok=True)
os.chdir(WORKSPACE)
from search_client import BingGroundingSearchClient, BingGroundingAPI, SearchLogger
from llm_client import AOAIClient
_llm = AOAIClient(model={search_model!r})
_logger = SearchLogger(log_dir={log_dir!r}) if {log_dir!r} else None
search_client = BingGroundingSearchClient(
    bing_grounding_api=BingGroundingAPI(), llm_client=_llm, logger=_logger,
)
"""


class ExecutePythonTool(BaseTool):
    def __init__(self, config: dict, tool_schema: OpenAIFunctionToolSchema = None):
        tool_schema = tool_schema or OpenAIFunctionToolSchema.model_validate(_TOOL_SCHEMA)
        super().__init__(config, tool_schema)
        self._inst: dict[str, dict] = {}
        self.search_model = config.get("search_model", "gpt-4.1-mini")
        self.startup_timeout = config.get("startup_timeout", 60)
        self.exec_timeout = config.get("exec_timeout", 300)
        self.base_dir = config.get("workspace_root", os.path.join(tempfile.gettempdir(), "grpo_rollouts"))
        os.makedirs(self.base_dir, exist_ok=True)

    def get_openai_tool_schema(self) -> OpenAIFunctionToolSchema:
        return self.tool_schema

    async def create(self, instance_id: Optional[str] = None,
                     create_kwargs: Optional[dict] = None, **kwargs) -> tuple[str, ToolResponse]:
        if create_kwargs:
            kwargs.update(create_kwargs)
        # Persistent per-rollout kernel: the custom agent loop injects a stable
        # _rollout_id into create_kwargs. We key one kernel+workspace by it and
        # REUSE it across all turns of the rollout (state + output file persist).
        rid = kwargs.get("_rollout_id") or instance_id or str(uuid4())
        if rid in self._inst:
            return rid, ToolResponse()  # reuse existing kernel for this rollout
        workspace = os.path.join(self.base_dir, rid)
        log_dir = os.path.join(workspace, "log")
        os.makedirs(log_dir, exist_ok=True)

        def _spin():
            ex = PythonExecutor(session_id=f"grpo_{rid}",
                                startup_timeout=self.startup_timeout,
                                timeout=self.exec_timeout)
            res = ex.run(_bootstrap_code(_REPO_ROOT, workspace, self.search_model, log_dir),
                         timeout=self.startup_timeout)
            return ex, res

        try:
            executor, boot = await asyncio.to_thread(_spin)
        except Exception as e:  # noqa: BLE001
            return rid, ToolResponse(text=f"[kernel-init-failed] {e}")
        self._inst[rid] = {"executor": executor, "workspace": workspace,
                           "instance_id": kwargs.get("instance_id"),
                           "ground_truth": kwargs.get("ground_truth")}
        ok = boot.get("ok", False)
        return rid, ToolResponse(text="" if ok else f"[bootstrap-warn] {boot.get('error')}")

    @rollout_trace_op
    async def execute(self, instance_id: str, parameters: dict[str, Any],
                      **kwargs) -> tuple[ToolResponse, float, dict]:
        st = self._inst.get(instance_id)
        if st is None:
            return ToolResponse(text="[error] tool instance not found"), 0.0, {}
        code = parameters.get("code", "")
        if not isinstance(code, str):
            code = str(code)
        try:
            result = await asyncio.to_thread(st["executor"].run, code)
            text = _format_exec_result(result)
        except Exception as e:  # noqa: BLE001
            text = f"[error] tool execution failed: {e}"
        return ToolResponse(text=text), 0.0, {}

    async def calc_reward(self, instance_id: str, **kwargs) -> float:
        return 0.0

    async def release(self, instance_id: str, **kwargs) -> None:
        # No-op: the agent loop calls this per tool-call, but we keep the kernel
        # alive for the whole rollout. Real teardown happens in release_rollout,
        # called once by WideSearchToolAgentLoop at episode end.
        return

    async def release_rollout(self, rollout_id: str, **kwargs) -> None:
        st = self._inst.pop(rollout_id, None)
        if st is None:
            return
        try:
            await asyncio.to_thread(st["executor"].shutdown)
        except Exception:  # noqa: BLE001
            pass
        shutil.rmtree(st["workspace"], ignore_errors=True)
