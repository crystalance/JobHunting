# GRPO Training Results — WideSearch code-act agent (Qwen2.5-7B)

**Date:** 2026-07-10 (run) / recorded 2026-07-13
**Run:** `run_grpo_train.sh` — GRPO, batch=8, group size G=8, lr 1e-6, kl_coef 0.001,
FSDP2 on 4×A100-80GB, sglang async multi-turn (hermes), persistent-env agent loop.
**Init policy:** `actor_init_v2` = SFT LoRA (`ckpt_train_v2`, 122 rejection-sampled
trajectories) merged into Qwen2.5-7B-Instruct.
**Reward:** WideSearch outcome F1 (`widesearch_reward.py`):
`R = 1.0·f1_item + 0.5·f1_row + 0.1·has_table − 0.1·cost − 0.1·constant_fill`.
**Splits:** train `ws_en_001–070`, val `ws_en_071–085` (excl 079), test `086–100` (untouched).

---

## 1. Headline

GRPO clearly improved the policy. Val f1_item (same 14 prompts, greedy, evaluated
every 5 steps) rose **0.270 → 0.402 (+0.132, +49% relative)** and surpassed the
SFT harness baseline (0.345). The run **stopped at step 25/30** because the disk
filled (100%, 0 GB) — not a training failure.

## 2. Validation trajectory (14 val prompts, greedy)

| step | f1_item | f1_row | has_table | score |
|-----:|--------:|-------:|----------:|------:|
| 0  (SFT init) | 0.270 | 0.116 | 0.57 | 0.371 |
| 5  | 0.245 | 0.064 | 0.43 | 0.298 |
| 10 | 0.317 | 0.114 | 0.57 | 0.417 |
| 15 | 0.308 | 0.119 | 0.64 | 0.410 |
| 20 | 0.347 | 0.172 | 0.71 | 0.497 |
| **25** | **0.402** | 0.157 | **0.71** | **0.538** |

- `has_table` 0.57 → 0.71: more rollouts now finish and write a valid table
  (directly addresses the truncation ceiling in
  `Learning/bug&fix/2026-07-10_grpo_truncation_ceiling.md`).
- The step-5 dip was transient noise; recovery from step 10 onward is monotonic.

## 3. Per-prompt val change (step 0 → 25)

Big gains on previously-failed prompts:
`ws_en_085` 0.00→0.86, `ws_en_076` 0.00→0.71, `ws_en_072` 0.00→0.68,
`ws_en_071` 0.73→0.88, `ws_en_077` 0.49→0.60, `ws_en_081` 0.78→0.89.
Regressions: `ws_en_083` 0.66→0.44, `ws_en_080` 0.58→0.38, `ws_en_078` 0.19→0.00,
`ws_en_074` 0.28→0.12. Still unsolved (0.00): `ws_en_073, 075, 084`.
Net: **6 improved / 5 regressed**, mean f1_item +0.132.

## 4. Baseline comparison

| policy | val f1_item | val f1_row | has_table | env |
|---|---|---|---|---|
| SFT (`ckpt_train_v2`) | 0.345 | 0.176 | 14/14 output | harness (sampled) |
| GRPO step-0 (= SFT init, greedy) | 0.270 | 0.116 | 0.57 | verl greedy |
| **GRPO step-25** | **0.402** | 0.157 | 0.71 | verl greedy |

The verl greedy environment scores the SFT init lower (0.270) than the harness
(0.345); within that same environment GRPO lifted it to 0.402.

## 5. Learning-signal health

- GRPO groups had real within-group reward spread on 7–8 of 8 groups/step
  (advantages ≠ 0); mean within-group std(f1_item) ~0.10–0.18.
- Same-prompt re-exposure (steps 1–15) showed net-positive drift (+0.021 early),
  strengthening through steps 20–25.

## 6. Incident — disk full at step 25 (blocker, not a training bug)

- `/dev/root` (993 GB) hit 100%. Each checkpoint = **~86 GB** (model 4×7.6 GB +
  full FSDP optimizer state ~60 GB). 5 checkpoints (5/10/15/20/25) + a separate
  283 GB `/home/dkidna/verl` tree exhausted the disk.
- **`global_step_25` is corrupt** (partial save: model rank_2 = 3.3 GB vs 7.6 GB).
  The 0.402 weights are **not recoverable** from it.
- Best **complete** checkpoint = **`global_step_20`** (val f1_item 0.347, has full
  optimizer state → resumable).

## 7. Decision & next steps (Plan A)

1. Free disk (delete corrupt `global_step_25`; drop optimizer states of
   `global_step_5/10/15`, keeping their model weights).
2. **Resume from `global_step_20`** for steps 21–30 with a checkpoint-retention
   cap so the disk cannot refill; recapture and finish past the 0.40 peak.
3. Merge best-by-val checkpoint to HF, confirm on val, then run the **untouched
   test set (086–100)** for the final number.

## 8. Artifacts

- Checkpoints: `post_training/grpo/checkpoints/train_scaled/global_step_{5,10,15,20}` (25 corrupt).
- Rollout dumps (per-rollout scores): `post_training/grpo/rollout_dumps/{train,val}/*.jsonl`.
- Log: `post_training/grpo/train_scaled.log`.
- Config: `post_training/grpo/run_grpo_train.sh`.
