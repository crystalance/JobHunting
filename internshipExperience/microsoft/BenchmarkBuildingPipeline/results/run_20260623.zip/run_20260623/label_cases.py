"""Per-case refresh/tier labeling for run_20260623.

Reads the authoritative per-instance DATA embedded in fact_explorer.html
(each instance carries: fact.refresh (static|dynamic), verified, refresh_tier
= TIER_A | TIER_B | DROP | null) and produces a per-case breakdown:

  - whether the case has any refresh (dynamic) facts
  - instance counts classified as STATIC / TIER_A / TIER_B / DROP
  - the static vs refresh portion per case

Output: printed table + per_case_labels.csv in the same run dir.
"""
import csv
import json
import re
from pathlib import Path

RUN = Path(__file__).resolve().parent
HTML = RUN / "fact_explorer.html"
OUT = RUN / "per_case_labels.csv"
REPORT = RUN / "report_run_20260623.html"
MARK_START = "<!-- PER_CASE_LABELS_START -->"
MARK_END = "<!-- PER_CASE_LABELS_END -->"


def load_data() -> dict:
    text = HTML.read_text(encoding="utf-8")
    # The file contains:  const DATA = {....};\nconst root = ...
    start = text.index("const DATA = ") + len("const DATA = ")
    end = text.index("\nconst root", start)
    blob = text[start:end].rstrip().rstrip(";")
    return json.loads(blob)


def classify(fact: dict, inst: dict) -> str:
    """Return one of STATIC | TIER_A | TIER_B | DROP for a single instance."""
    if fact.get("refresh") == "static":
        return "STATIC"
    tier = inst.get("refresh_tier")
    if tier in ("TIER_A", "TIER_B", "DROP"):
        return tier
    # dynamic but unlabeled tier -> fall back on verified flag
    return "DROP" if not inst.get("verified") else "TIER_B"


def main() -> None:
    data = load_data()
    rows = []
    for c in data["cases"]:
        counts = {"STATIC": 0, "TIER_A": 0, "TIER_B": 0, "DROP": 0}
        n_refresh_facts = 0
        for f in c["facts"]:
            if f.get("refresh") != "static":
                n_refresh_facts += 1
            for i in f["instances"]:
                counts[classify(f, i)] += 1
        total = sum(counts.values())
        refresh_inst = counts["TIER_A"] + counts["TIER_B"] + counts["DROP"]
        static_inst = counts["STATIC"]
        rows.append({
            "case_id": c["case_id"],
            "has_refresh": "yes" if n_refresh_facts else "no",
            "n_facts": c.get("n_facts", len(c["facts"])),
            "n_refresh_facts": n_refresh_facts,
            "instances": total,
            "static": static_inst,
            "tier_a": counts["TIER_A"],
            "tier_b": counts["TIER_B"],
            "drop": counts["DROP"],
            "static_pct": round(100 * static_inst / total, 1) if total else 0.0,
            "refresh_pct": round(100 * refresh_inst / total, 1) if total else 0.0,
        })

    # Sort: cases with refresh first, then by refresh portion desc
    rows.sort(key=lambda r: (r["has_refresh"] != "yes", -r["refresh_pct"], r["case_id"]))

    # Console table
    hdr = f"{'case_id':<34} {'refr':>4} {'inst':>5} {'stat':>5} {'A':>4} {'B':>4} {'drop':>5} {'stat%':>6} {'refr%':>6}"
    print(hdr)
    print("-" * len(hdr))
    for r in rows:
        print(f"{r['case_id']:<34} {r['has_refresh']:>4} {r['instances']:>5} "
              f"{r['static']:>5} {r['tier_a']:>4} {r['tier_b']:>4} {r['drop']:>5} "
              f"{r['static_pct']:>6} {r['refresh_pct']:>6}")

    # Totals
    tot = {k: sum(r[k] for r in rows) for k in ("instances", "static", "tier_a", "tier_b", "drop")}
    n_with_refresh = sum(1 for r in rows if r["has_refresh"] == "yes")
    print("-" * len(hdr))
    print(f"{'TOTAL ('+str(len(rows))+' cases, '+str(n_with_refresh)+' with refresh)':<34} "
          f"{'':>4} {tot['instances']:>5} {tot['static']:>5} {tot['tier_a']:>4} "
          f"{tot['tier_b']:>4} {tot['drop']:>5}")

    with OUT.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"\nWrote {OUT}")

    inject_report(rows, tot, n_with_refresh)


def _band(refresh_pct: float, has_refresh: str) -> str:
    if has_refresh != "yes":
        return ""
    if refresh_pct >= 80:
        return "band-100"
    if refresh_pct >= 50:
        return "band-80"
    return "band-50"


def build_section(rows, tot, n_with_refresh) -> str:
    out = [MARK_START]
    out.append('<h2>5. Per-case refresh / tier breakdown</h2>')
    out.append('<p class="small">Instance-level labels from <a href="fact_explorer.html">Fact Explorer</a> '
               '(authoritative per-instance <code>refresh</code> + <code>refresh_tier</code>). '
               'Each instance is <strong>STATIC</strong> (refresh=static), or, when dynamic, '
               '<strong>TIER_A</strong> (deterministic fetcher reproduces offline + live), '
               '<strong>TIER_B</strong> (verified, needs llm_playbook), or '
               '<strong>DROP</strong> (no verified value). '
               'Rows shaded by refresh share: green &ge;80%, light-green 50-79%, amber 1-49%, white = pure static.</p>')
    out.append(f'<div class="callout info"><strong>{n_with_refresh} / {len(rows)} cases contain refresh '
               f'(dynamic) facts</strong>; the remaining {len(rows) - n_with_refresh} are 100% static. '
               f'Instance totals &mdash; static <strong>{tot["static"]}</strong>, '
               f'TIER_A <strong>{tot["tier_a"]}</strong>, TIER_B <strong>{tot["tier_b"]}</strong>, '
               f'DROP <strong>{tot["drop"]}</strong> '
               f'(dynamic = {tot["tier_a"] + tot["tier_b"] + tot["drop"]}).<br>'
               '<span class="small">Note: TIER_A/B here are per-instance <code>refresh_tier</code> labels; '
               'the section-3 headline (72/48) counts <em>qualified</em> instances from the run summary &mdash; '
               'a definitional difference. Dynamic total (175) and DROP (55) match exactly.</span></div>')
    out.append('<table><thead><tr><th>Case</th><th>Refresh?</th><th>Facts</th><th>Refresh facts</th>'
               '<th>Instances</th><th>Static</th><th>Tier A</th><th>Tier B</th><th>Drop</th>'
               '<th>Static %</th><th>Refresh %</th></tr></thead><tbody>')
    for r in rows:
        band = _band(r["refresh_pct"], r["has_refresh"])
        cls = f' class="{band}"' if band else ""
        out.append(
            f'<tr{cls}><td>{r["case_id"]}</td><td>{r["has_refresh"]}</td><td>{r["n_facts"]}</td>'
            f'<td>{r["n_refresh_facts"]}</td><td>{r["instances"]}</td><td>{r["static"]}</td>'
            f'<td>{r["tier_a"]}</td><td>{r["tier_b"]}</td><td>{r["drop"]}</td>'
            f'<td>{r["static_pct"]}</td><td>{r["refresh_pct"]}</td></tr>')
    out.append(f'<tr><td><strong>TOTAL</strong></td><td>{n_with_refresh} yes</td><td></td><td></td>'
               f'<td><strong>{tot["instances"]}</strong></td><td><strong>{tot["static"]}</strong></td>'
               f'<td><strong>{tot["tier_a"]}</strong></td><td><strong>{tot["tier_b"]}</strong></td>'
               f'<td><strong>{tot["drop"]}</strong></td><td></td><td></td></tr>')
    out.append('</tbody></table>')
    out.append(MARK_END)
    return "\n".join(out)


def inject_report(rows, tot, n_with_refresh) -> None:
    if not REPORT.exists():
        print(f"(report not found, skipped: {REPORT})")
        return
    section = build_section(rows, tot, n_with_refresh)
    text = REPORT.read_text(encoding="utf-8")
    if MARK_START in text and MARK_END in text:
        pre = text[:text.index(MARK_START)]
        post = text[text.index(MARK_END) + len(MARK_END):]
        text = pre + section + post
    else:
        anchor = "<h2>5. Pipeline stages (this run)</h2>"
        if anchor in text:
            # bump the existing section 5 to 6 and insert ours before it
            text = text.replace(anchor, section + "\n\n<h2>6. Pipeline stages (this run)</h2>")
        else:
            text = text.replace("</body>", section + "\n</body>")
    REPORT.write_text(text, encoding="utf-8")
    print(f"Injected per-case section into {REPORT.name}")


if __name__ == "__main__":
    main()
