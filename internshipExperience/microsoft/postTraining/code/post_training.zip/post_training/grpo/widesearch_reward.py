"""
WideSearch outcome reward for GRPO (verl custom_reward_function).

compute_score() scores the policy's FINAL answer (which contains the markdown
table) against the gold table via the WideSearch evaluator, then applies the
shaping terms from the design:

    R = w_item*f1_item + w_row*f1_row + w_out*has_table
        - w_cost*min(n_turns/turn_budget, 1) - w_fab*constant_fill

Reuses the exact evaluator path from post_training/sft/score_trajectories.py
(gold-verified, gpt-4.1 judge for free-text columns). Queries + gold are loaded
ONCE at import and indexed by instance_id.

Wire in verl:
    custom_reward_function.path=post_training/grpo/widesearch_reward.py
    custom_reward_function.name=compute_score
The parquet must set reward_model.ground_truth = instance_id (ws_en_###).
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

_WIDESEARCH_ROOT = os.getenv("WIDESEARCH_ROOT", "/home/dkidna/WideSearch")

# Reward weights (design 7_20 §4 — v3): keep coverage weight high (0.8), give
# has_table a real positive term (0.1), and REMOVE the turn-cost term (W_COST=0)
# — the turn penalty was the root cause of the v2 collapse (it paid the policy to
# stop before finishing). Efficiency now comes from the KL anchor to the already-
# efficient SFT-v3 policy, not from a penalty. A hard no-table floor guarantees
# "finish > give up" structurally (see compute_score).
W_ITEM = float(os.getenv("GRPO_W_ITEM", "1.0"))
W_ROW = float(os.getenv("GRPO_W_ROW", "0.8"))
W_OUT = float(os.getenv("GRPO_W_OUT", "0.1"))
W_COST = float(os.getenv("GRPO_W_COST", "0.0"))
W_FAB = float(os.getenv("GRPO_W_FAB", "0.1"))
TURN_BUDGET = float(os.getenv("GRPO_TURN_BUDGET", "12"))
# Hard floor applied when the rollout produced no scoreable table, so "no table"
# is always the strict minimum (removes the collapse absorbing-state). Set
# GRPO_NO_TABLE_FLOOR="" (empty) to disable.
_NO_TABLE_FLOOR_RAW = os.getenv("GRPO_NO_TABLE_FLOOR", "-0.1")
NO_TABLE_FLOOR = float(_NO_TABLE_FLOOR_RAW) if _NO_TABLE_FLOOR_RAW != "" else None

_INIT_LOCK = threading.Lock()
_READY = False
_Q_BY_ID = {}
_EVAL = None
_LOADER = None
_DETECT_CFILL = None


def _lazy_init():
    """Import WideSearch eval + our harness helpers, patch the Azure judge, and
    load all queries once. Thread-safe."""
    global _READY, _Q_BY_ID, _EVAL, _LOADER, _DETECT_CFILL
    if _READY:
        return
    with _INIT_LOCK:
        if _READY:
            return
        from search_agent.batch_eval import (
            _ensure_widesearch_importable, _patch_widesearch_eval_client,
            load_widesearch_queries,
        )
        from pathlib import Path
        _ensure_widesearch_importable(Path(_WIDESEARCH_ROOT))
        _patch_widesearch_eval_client()
        from src.evaluation.data_loader import WideSearchResponseLoader
        from src.evaluation.evaluation import evaluate_single_query
        from post_training.sft.score_trajectories import _detect_constant_fill
        _EVAL = evaluate_single_query
        _LOADER = WideSearchResponseLoader
        _DETECT_CFILL = _detect_constant_fill
        qs = load_widesearch_queries(Path(_WIDESEARCH_ROOT), None, None)
        _Q_BY_ID = {q.instance_id: q for q in qs}
        _READY = True


def _score_response(instance_id: str, response_text: str):
    """Return (f1_row, f1_item) for a response vs gold, or (0,0) on failure."""
    q = _Q_BY_ID.get(instance_id)
    if q is None or not response_text:
        return 0.0, 0.0
    tmp = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix="_response.jsonl", delete=False) as f:
            f.write(json.dumps({"instance_id": instance_id, "response": response_text},
                               ensure_ascii=False) + "\n")
            tmp = f.name
        resp_list = _LOADER.load_response(tmp)
        resp = resp_list[0] if resp_list else None
        if resp is None or str(resp.response).startswith("ERROR:"):
            return 0.0, 0.0
        ev = _EVAL(q, resp, tmp + ".csv")
        return float(ev.f1_by_row), float(ev.f1_by_item)
    except Exception:  # noqa: BLE001
        return 0.0, 0.0
    finally:
        for p in (tmp, (tmp + ".csv") if tmp else None):
            if p and os.path.exists(p):
                try:
                    os.unlink(p)
                except OSError:
                    pass


def compute_score(data_source, solution_str, ground_truth, extra_info=None, **kwargs):
    """verl reward entry point. ground_truth = instance_id (ws_en_###)."""
    _lazy_init()
    instance_id = str(ground_truth)
    extra_info = extra_info or {}

    f1_row, f1_item = _score_response(instance_id, solution_str or "")
    has_table = 1.0 if (f1_item > 0.0 or f1_row > 0.0) else 0.0
    try:
        constant_fill = 1.0 if _DETECT_CFILL and _detect_from_text(solution_str) else 0.0
    except Exception:  # noqa: BLE001
        constant_fill = 0.0
    n_turns = float(extra_info.get("num_turns") or 0)
    if not n_turns and solution_str:
        # verl doesn't pass num_turns; count execute_python tool-call turns from
        # the response so the efficiency/cost term is actually active.
        n_turns = float(solution_str.count("<tool_call>") or solution_str.count('"execute_python"'))
    cost = min(n_turns / TURN_BUDGET, 1.0) if TURN_BUDGET > 0 else 0.0

    # v3: hard floor — a rollout that produced no scoreable table is always the
    # strict worst, so RL can never settle into the "stop early, no table"
    # absorbing state that collapsed v2.
    if NO_TABLE_FLOOR is not None and has_table == 0.0:
        score = NO_TABLE_FLOOR
    else:
        score = (W_ITEM * f1_item + W_ROW * f1_row + W_OUT * has_table
                 - W_COST * cost - W_FAB * constant_fill)
    return {
        "score": score,
        "f1_row": f1_row,
        "f1_item": f1_item,
        "has_table": has_table,
        "n_turns": n_turns,
        "constant_fill": constant_fill,
    }


def _detect_from_text(text: str) -> bool:
    """Run the constant-fill heuristic directly on the answer text (writes a
    temp file because _detect_constant_fill takes a path)."""
    if not text:
        return False
    tmp = None
    try:
        with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False) as f:
            f.write(text)
            tmp = f.name
        return bool(_DETECT_CFILL(tmp))
    finally:
        if tmp and os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass
