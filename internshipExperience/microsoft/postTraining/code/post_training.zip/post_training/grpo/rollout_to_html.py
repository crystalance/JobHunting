"""
Render verl GRPO rollout dumps (rollout_dumps/{train,val}/<step>.jsonl) into a
single self-contained HTML report for inspection + comparison.

Each dumped rollout has: input (prompt), output (full hermes multi-turn text),
gts (instance_id), score (reward), f1_row, f1_item, has_table, n_turns,
constant_fill, step. We parse `output` into turns (tool_call thought/code +
tool_response stdout + final answer) and render:
  - a comparison summary table (all rollouts, sortable by score),
  - a collapsible per-rollout trajectory detail.

Usage:
  python post_training/grpo/rollout_to_html.py \
      --dumps post_training/grpo/rollout_dumps \
      --out post_training/Learning/progress/grpo_rollouts.html
"""
from __future__ import annotations

import argparse
import glob
import html
import json
import os
import re

_TOOLCALL_RE = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", re.DOTALL)
_TOOLRESP_RE = re.compile(r"<tool_response>(.*?)</tool_response>", re.DOTALL)


def _esc(s, n=None):
    s = s or ""
    if n and len(s) > n:
        s = s[:n] + f"\n… [+{len(s)-n} chars]"
    return html.escape(s)


def _parse_turns(output: str):
    """Split the raw generation into ordered events: assistant tool_calls,
    tool_responses, and the final plain-text answer."""
    events = []
    pos = 0
    # Interleave tool_calls and tool_responses in order of appearance.
    marks = []
    for m in _TOOLCALL_RE.finditer(output):
        marks.append((m.start(), "call", m))
    for m in _TOOLRESP_RE.finditer(output):
        marks.append((m.start(), "resp", m))
    marks.sort(key=lambda x: x[0])
    last_end = 0
    for _, kind, m in marks:
        if kind == "call":
            try:
                obj = json.loads(m.group(1))
                args = obj.get("arguments", {})
                if isinstance(args, str):
                    args = json.loads(args)
                events.append(("call", args.get("thought", ""), args.get("code", "")))
            except Exception:
                events.append(("call", "", m.group(1)))
        else:
            events.append(("resp", m.group(1).strip(), ""))
        last_end = m.end()
    # trailing text after the last tag = final answer (strip role tokens)
    tail = output[last_end:]
    tail = re.sub(r"^\s*(assistant|user)\s*", "", tail).strip()
    tail = tail.replace("<|im_end|>", "").strip()
    if tail:
        events.append(("final", tail, ""))
    return events


def _load(dumps_dir):
    rows = []
    for split in ("val", "train"):
        for f in sorted(glob.glob(os.path.join(dumps_dir, split, "*.jsonl"))):
            step = os.path.splitext(os.path.basename(f))[0]
            for i, line in enumerate(open(f, encoding="utf-8")):
                line = line.strip()
                if not line:
                    continue
                d = json.loads(line)
                d["_split"] = split
                d["_step"] = step
                d["_idx"] = i
                rows.append(d)
    return rows


_CSS = """
body{margin:0;background:#0f1420;color:#e6ebf5;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;line-height:1.55;font-size:14px}
.wrap{max-width:1100px;margin:0 auto;padding:28px 22px 80px}
h1{font-size:26px;margin:0 0 4px}h2{font-size:20px;margin:34px 0 10px;border-bottom:2px solid #2a3550;padding-bottom:6px;color:#5aa9ff}
.sub{color:#9aa7bd;margin-bottom:22px}
table{width:100%;border-collapse:collapse;margin:10px 0;font-size:13px}
th,td{padding:7px 9px;border-bottom:1px solid #2a3550;text-align:left}
th{color:#9aa7bd;text-transform:uppercase;font-size:11px;letter-spacing:.4px}
code,pre{font-family:SFMono-Regular,Consolas,monospace}
pre{background:#0b1020;border:1px solid #2a3550;border-radius:7px;padding:9px 11px;overflow:auto;font-size:12px;color:#cfe3ff;white-space:pre-wrap;word-break:break-word;margin:5px 0}
details{background:#171e2e;border:1px solid #2a3550;border-radius:10px;margin:9px 0;padding:6px 12px}
summary{cursor:pointer;font-weight:600}
.turn{border-left:3px solid #2a3550;margin:8px 0;padding-left:10px}
.tt{color:#cdd8ee;font-size:12.5px;margin:3px 0}
.badge{display:inline-block;padding:1px 8px;border-radius:999px;font-size:12px;font-weight:600;margin-right:6px}
.good{background:rgba(74,222,128,.15);color:#4ade80}.bad{background:rgba(248,113,113,.15);color:#f87171}
.warn{background:rgba(251,191,36,.15);color:#fbbf24}.info{background:rgba(90,169,255,.15);color:#5aa9ff}
.call{color:#8fb8e8}.resp{color:#a7f3c0}.final{color:#fbbf24}
.mono{font-family:SFMono-Regular,Consolas,monospace}
"""


def _badge(v, hi=0.5, mid=0.2):
    cls = "good" if v >= hi else ("warn" if v >= mid else "bad")
    return f'<span class="badge {cls}">{v:.3f}</span>'


def render(rows, out_path):
    rows.sort(key=lambda r: (r["_split"], r["_step"], -float(r.get("score", 0) or 0)))
    parts = ['<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">',
             f"<style>{_CSS}</style><title>GRPO Rollouts</title></head><body><div class='wrap'>"]
    parts.append("<h1>GRPO Rollout Inspection</h1>")
    parts.append(f"<div class='sub'>{len(rows)} rollouts from post_training/grpo/rollout_dumps/ &nbsp;·&nbsp; "
                 "val = greedy validation (do_sample=False), train = sampled GRPO rollouts (group of G). "
                 "score = reward; f1_row / f1_item = WideSearch gold-verified.</div>")

    # summary table
    parts.append("<h2>1. Comparison summary</h2>")
    parts.append("<table><tr><th>#</th><th>split</th><th>step</th><th>instance</th>"
                 "<th>reward</th><th>f1_row</th><th>f1_item</th><th>has_table</th>"
                 "<th>n_turns</th><th>const_fill</th></tr>")
    for i, r in enumerate(rows):
        parts.append(
            f"<tr><td>{i+1}</td><td>{r['_split']}</td><td>{r['_step']}</td>"
            f"<td class='mono'>{_esc(str(r.get('gts')))}</td>"
            f"<td>{_badge(float(r.get('score',0) or 0))}</td>"
            f"<td>{_badge(float(r.get('f1_row',0) or 0))}</td>"
            f"<td>{_badge(float(r.get('f1_item',0) or 0))}</td>"
            f"<td>{'yes' if float(r.get('has_table',0) or 0) else 'no'}</td>"
            f"<td>{int(float(r.get('n_turns',0) or 0))}</td>"
            f"<td>{'YES' if float(r.get('constant_fill',0) or 0) else '-'}</td></tr>")
    parts.append("</table>")

    # per-rollout detail
    parts.append("<h2>2. Rollout trajectories</h2>")
    for i, r in enumerate(rows):
        events = _parse_turns(r.get("output") or "")
        n_calls = sum(1 for e in events if e[0] == "call")
        head = (f"#{i+1} · <span class='mono'>{_esc(str(r.get('gts')))}</span> · {r['_split']} step {r['_step']} · "
                f"reward {float(r.get('score',0) or 0):.3f} · f1_row {float(r.get('f1_row',0) or 0):.2f} · "
                f"f1_item {float(r.get('f1_item',0) or 0):.2f} · {n_calls} tool-calls")
        parts.append(f"<details><summary>{head}</summary>")
        # task
        task = r.get("input") or ""
        task = re.split(r"user\n", task)[-1] if "user\n" in task else task
        parts.append(f"<div class='turn'><div class='tt info'>TASK</div><pre>{_esc(task, 700)}</pre></div>")
        tn = 0
        for kind, a, b in events:
            if kind == "call":
                tn += 1
                parts.append(f"<div class='turn'><div class='tt call'>Turn {tn} · thought</div>"
                             f"<pre>{_esc(a, 400)}</pre>"
                             f"<div class='tt call'>code</div><pre>{_esc(b, 700)}</pre></div>")
            elif kind == "resp":
                parts.append(f"<div class='turn'><div class='tt resp'>tool result</div>"
                             f"<pre>{_esc(a, 500)}</pre></div>")
            else:
                parts.append(f"<div class='turn'><div class='tt final'>FINAL ANSWER</div>"
                             f"<pre>{_esc(a, 1500)}</pre></div>")
        parts.append("</details>")

    parts.append("</div></body></html>")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("".join(parts))
    print(f"wrote {len(rows)} rollouts -> {out_path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dumps", default="post_training/grpo/rollout_dumps")
    ap.add_argument("--out", default="post_training/Learning/progress/grpo_rollouts.html")
    args = ap.parse_args()
    rows = _load(args.dumps)
    if not rows:
        raise SystemExit(f"no rollout dumps found under {args.dumps}")
    render(rows, args.out)


if __name__ == "__main__":
    main()
