"""
Score the teacher_gen_v3 rollouts (all shards, all k samples) with the WideSearch
evaluator, keeping PER-(case,trial) f1 so the SFT builder can do f1_row-gated
top-N-per-case selection. Reports yield.

  .venv-harness/bin/python post_training/grpo/score_teacher_gen.py [gen_dir]
"""
import glob
import json
import os
import re
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from statistics import mean

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from post_training.grpo import widesearch_reward as R

GEN = sys.argv[1] if len(sys.argv) > 1 else "post_training/grpo/teacher_gen_v3"


def score_file(path):
    m = re.search(r"(ws_(?:en|zh)_\d+)(?:__t(\d+))?_response\.jsonl$", os.path.basename(path))
    if not m:
        return None
    iid = m.group(1)
    trial = int(m.group(2)) if m.group(2) else 0
    try:
        resp = json.loads(open(path).readline()).get("response", "") or ""
    except Exception:
        resp = ""
    f1_row, f1_item = R._score_response(iid, resp)
    return {"iid": iid, "trial": trial, "f1_row": f1_row, "f1_item": f1_item,
            "trace": os.path.join(os.path.dirname(path), f"{iid}" + (f"__t{trial}" if m.group(2) else ""), "agent_trace.json")}


def main():
    R._lazy_init()
    files = sorted(glob.glob(os.path.join(GEN, "shard_*", "*_response.jsonl")))
    print(f"scoring {len(files)} rollouts ...")
    rows = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futs = [pool.submit(score_file, f) for f in files]
        for fu in as_completed(futs):
            r = fu.result()
            if r:
                rows.append(r)
    json.dump(rows, open(os.path.join(GEN, "scores.json"), "w"), indent=1)

    def lang(iid): return "en" if "_en_" in iid else "zh"
    by_lang = defaultdict(list)
    for r in rows:
        by_lang[lang(r["iid"])].append(r)
    print(f"\nscored {len(rows)} rollouts | EN {len(by_lang['en'])} ZH {len(by_lang['zh'])}")
    print(f"{'lang':4s} | {'mean f1_item':>12s} | {'mean f1_row':>11s}")
    for lg in ("en", "zh"):
        v = by_lang[lg]
        if v:
            print(f"{lg:4s} | {mean(x['f1_item'] for x in v):12.3f} | {mean(x['f1_row'] for x in v):11.3f}")

    # yield: distinct cases with >=1 sample passing at (f1_item>=IT and f1_row>=RW)
    print("\n=== yield: cases with >=1 passing sample, and total selectable (top-2/case) ===")
    for it, rw in [(0.5, 0.0), (0.5, 0.3), (0.6, 0.3), (0.6, 0.5)]:
        by_case = defaultdict(list)
        for r in rows:
            if r["f1_item"] >= it and r["f1_row"] >= rw:
                by_case[r["iid"]].append(r)
        cases = len(by_case)
        top2 = sum(min(2, len(v)) for v in by_case.values())
        en_c = sum(1 for k in by_case if lang(k) == "en")
        zh_c = sum(1 for k in by_case if lang(k) == "zh")
        print(f"  f1_item>={it} & f1_row>={rw}:  cases={cases} (EN {en_c}/70, ZH {zh_c}/70) | top-2/case traces={top2}")


if __name__ == "__main__":
    main()
