# Training Strategy — v3: Enumerate-then-Loop Code-Act (SFT → GRPO)

**Date:** 2026-07-14
**Author's objective:** teach an open small model (Qwen2.5-7B) the *efficient* code-act
pattern — **construct queries programmatically over a discovered entity set and batch
them in one code block** — to cut LLM round-trips (time/cost) *and* raise coverage/F1.
**Approach chosen:** add the pattern at the **SFT** stage, retrain SFT **from base**, then
**re-run GRPO** to polish efficiency. Canonical order: *SFT teaches capability, RL polishes*.
Sidesteps the RL→SFT forgetting question entirely.

---

## 0. Why this plan (what the data told us)

| Finding (from v2 runs) | Implication for v3 |
|---|---|
| GRPO tied SFT on held-out **f1_item** (0.347→0.344) | RL alone can't fix accuracy; the ceiling is elsewhere |
| Failure = **coverage/recall** (ZH row recall 0.05 vs prec 0.11) | Must find *more entities* → programmatic per-entity search |
| **GRPO cut LLM turns −48%** (10.6→5.5) at equal coverage | RL *is* good at efficiency → keep it as the polish step |
| 100% for-loop, but only **42%** loop-*construct* queries; 58% hand-list | Teach **enumerate-then-loop** construction, not hand-lists |
| Greedy val non-reproducible; 14-prompt val → selection bias | Bigger val + multi-sample eval, report test only |
| verl ckpt ~86 GB, disk filled | Cap `max_actor_ckpt_to_keep`; merge+delete optim |

**Core insight:** the pattern that maximizes *coverage* (loop over a discovered entity list,
one targeted search per row) is the *same* pattern that is cleanest/most efficient code-act.
So one change — **enumerate-then-loop** — advances both the accuracy and the efficiency goal.

---

## 1. The target pattern (spec)

Two-phase code-act trajectory the model should learn:

```python
# Phase A — DISCOVER the entity/row set (1 search turn)
res = search_client.search("complete list of <all entities for the task>")
entities = parse_entities(res)          # -> ['A', 'B', 'C', ...]

# Phase B — CONSTRUCT queries in a loop, batch them (1 search turn for many rows)
queries = [f"{e} <needed attributes> source" for e in entities]
results = search_client.search(queries)  # N searches, ONE LLM round-trip

# Phase C — parse into rows, write output table; re-search only rows still nan
```

Why it helps both axes:
- **Coverage/recall ↑:** every row gets its own targeted search (vs a fixed hand-guessed list).
- **Efficiency ↑:** N searches per code block → few LLM turns.
- **Verifiable:** a final pass re-searches empty (`nan`) rows before finalizing.

---

## 2. Success metrics & decision gates

Measure **both axes** at every stage (accuracy *and* efficiency); forgetting/regression is
invisible if you only track F1.

| Axis | Metric | v2 baseline (EN test) | v3 target |
|---|---|---|---|
| Accuracy | f1_item | 0.347 | ≥ 0.40 |
| Coverage | f1_row / row-recall | 0.118 / ~0.09 | row-recall ↑ ≥ +30% |
| Efficiency | LLM turns/task | 5.5 (GRPO) / 10.6 (SFT) | ≤ 5, hold |
| Pattern | % enumerate-then-loop | 42% | ≥ 80% |
| Chinese | f1_item (ZH) | 0.23 | ≥ 0.28 |

**Gates:**
- After SFT: pattern% ≥ 80% AND f1_item ≥ v2 SFT (0.35) → proceed to GRPO.
- After GRPO: test f1_item ≥ SFT AND turns ≤ SFT → ship; else diagnose.
- Always: multi-sample (n≥4), shared/frozen search cache, **report test only**.

---

## 3. Phase 1 — SFT data generation (teach the pattern)

**Goal:** a cold-start set whose trajectories demonstrate enumerate-then-loop + high recall + correct values, in EN *and* ZH.

**Sources (blend):**
1. **Teacher distillation (gpt-5.4 + gpt-4.1-mini search)** on train prompts (EN 001–070, ZH train), with a system prompt that *explicitly instructs* enumerate-then-loop. Search MUST stay gpt-4.1-mini (hard rule).
2. **Self-distillation / RFT from step_30:** mine step_30 rollouts that already use enumerate-then-loop AND score high (≈42% do) — on-distribution, cheap.
3. **A few hand-written canonical exemplars** to seed the exact template.

**Filter (quality bar):** keep a trajectory iff
- uses enumerate-then-loop (detected by `analyze_codeact.py`-style check on the code),
- f1_item ≥ 0.5 (higher bar than v1 — the pattern is learned; now teach correctness),
- completes with a written output table, fits context window (≤ 28,672 tok).
- Rejection-sample k=4/prompt, keep best-by-f1 that matches the pattern. Balance EN/ZH.

**Builder:** extend `post_training/sft/build_sft_data.py` with a pattern filter; assistant-only loss mask.

---

## 4. Phase 2 — SFT training (from base Qwen)

- **Init:** base `Qwen2.5-7B-Instruct` (fresh — no forgetting risk).
- **Method:** LoRA r32/a64 all-linear (bf16, flash-attn2), `train_sft.py`; lr 1e-4, 3 epochs, MAX_LEN 28,672, assistant-only mask.
- **System prompt:** update `_SYSTEM_PROMPT` to instruct the enumerate-then-loop pattern (keep SFT and inference prompts identical).
- **Output:** merge LoRA → `actor_init_v3` (full HF) for the RL actor.
- **Gate check:** run `analyze_codeact.py` + a quick val eval; require pattern% ≥ 80% before RL.

---

## 5. Phase 3 — GRPO (polish efficiency + nudge coverage)

- **Init actor:** `actor_init_v3` (merged v3 SFT). Ref = frozen v3 SFT.
- **Reward v2 (correctness + efficiency), fix the known gaps:**
  ```
  R = 1.0·f1_item + 0.8·f1_row            # up-weight row/recall (was 0.5)
    + 0.1·has_table
    − 0.1·turn_cost                        # FIX: plumb real num_turns (was inert)
    − 0.1·constant_fill                    # anti-nan-fabrication (keep/strengthen)
  ```
  - **Plumb `num_turns`** into the reward (via AgentLoopOutput or count `<tool_call>` in solution_str) so efficiency is optimized *deliberately*, not emergently.
  - Consider per-cell partial credit so `nan`-filling can't game item-F1.
- **Config:** batch 8, G=8, lr 1e-6, **kl_coef 0.01** (↑ from 0.001 to avoid the regression tax that turned a 1.00→0.73), FSDP2 4×A100, `max_actor_ckpt_to_keep=2`, sglang multi-turn, persistent-env agent loop, shared search cache.
- **Selection:** validate on a **larger val set** (≥ 30 prompts) every 5 steps, multi-sample.

---

## 6. Phase 4 — Evaluation (variance-controlled)

- Merge best-by-val ckpt → HF; serve one vLLM per GPU (`eval_checkpoints.sh`).
- Multi-sample (**n≥4**, temp 0.7), **shared frozen search cache**, one session.
- Report on **held-out test** (EN 086–100 + a held-out ZH split), never used for selection.
- **Score both axes:** `score_eval_responses.py` (f1_item/row/recall) + `analyze_codeact.py` (turns/batch/pattern%).
- Compare: **base → v3-SFT → v3-GRPO** on accuracy AND efficiency.

---

## 7. Risks & mitigations

| Risk | Mitigation |
|---|---|
| Disk fills (verl ckpt ~86 GB) | `max_actor_ckpt_to_keep=2`; merge → delete optim after |
| Greedy eval non-reproducible | multi-sample eval always; never trust single greedy |
| Val selection bias | val ≥ 30 prompts; report test only |
| Reward gaming (`nan` fill) | per-cell partial credit + `constant_fill` penalty |
| Chinese search quality | verify gpt-4.1-mini summarizes ZH; add ZH to SFT |
| Losing efficiency in SFT | pattern is *in* the SFT data; re-measure turns after SFT |
| Coverage bounded by search | verification/second-pass search for empty rows |

---

## 8. Execution checklist (ordered)

1. [ ] Update `_SYSTEM_PROMPT` → enumerate-then-loop instruction.
2. [ ] Generate teacher (gpt-5.4) traces on EN+ZH train with the new prompt.
3. [ ] Add pattern filter to `build_sft_data.py`; select high-F1 + enumerate-then-loop (+ mine step_30 rollouts).
4. [ ] SFT LoRA from base → merge → `actor_init_v3`. Gate: pattern% ≥ 80%, f1 ≥ 0.35.
5. [ ] Plumb `num_turns` into `widesearch_reward.py`; reward v2 (↑f1_row, real turn_cost, KL 0.01).
6. [ ] GRPO from `actor_init_v3`; larger val; cap checkpoints.
7. [ ] Merge best ckpt; multi-sample test eval (EN+ZH) on both axes.
8. [ ] Record: base → v3-SFT → v3-GRPO table (accuracy + efficiency) in progress HTML.

---

## 9. Expected story (if it works)

> SFT (from base) teaches an **enumerate-then-loop** code-act pattern (discover entities →
> loop-construct queries → batched search), lifting coverage/recall and f1; GRPO with a
> **turn-aware reward** then polishes it to ≤5 LLM round-trips/task at equal-or-better
> accuracy — a small model that searches *exhaustively* and *cheaply*.

Artifacts to produce: `actor_init_v3`, reward v2, larger val set, v3 test scores + code-act
metrics, updated progress HTML.
