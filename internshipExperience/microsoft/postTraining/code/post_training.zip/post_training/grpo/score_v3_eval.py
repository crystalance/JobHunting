"""One-off: score the v3 controlled eval (EN+ZH), split by language.
Reuses widesearch_reward._score_response (WideSearch evaluator + gpt-4.1 judge).
Writes controlled_scores_v3.json + a clean SUMMARY block at the end of stdout.
"""
import glob, json, os, re, sys
from collections import defaultdict
from statistics import mean
from concurrent.futures import ThreadPoolExecutor, as_completed
sys.path.insert(0, "/home/dkidna/WebSearchResearch")
from post_training.grpo import widesearch_reward as R
R._lazy_init()

EVAL = "post_training/grpo/eval_20260721_040025"
MODELS = ["sft_v3", "grpo_v3"]
pat = re.compile(r"(ws_(?:en|zh)_\d+)__t(\d+)_response\.jsonl$")


def score_file(p):
    m = pat.search(os.path.basename(p))
    if not m:
        return None
    iid = m.group(1)
    try:
        obj = json.loads(open(p).readline())
        resp = obj.get("response", "") or ""
    except Exception:
        resp = ""
    fr, fi = R._score_response(iid, resp)
    return (iid, fr, fi)


def agg(results):
    bp_i, bp_r = defaultdict(list), defaultdict(list)
    for iid, fr, fi in results:
        bp_i[iid].append(fi)
        bp_r[iid].append(fr)
    item = mean([mean(v) for v in bp_i.values()])
    row = mean([mean(v) for v in bp_r.values()])
    p4 = mean([max(v) for v in bp_i.values()])
    ht = mean([1.0 if fi > 0 or fr > 0 else 0.0 for _, fr, fi in results])
    return item, row, ht, p4, len(results), len(bp_i)


out = {}
for name in MODELS:
    files = sorted(glob.glob(os.path.join(EVAL, name, "*__t*_response.jsonl")))
    res = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        for fu in as_completed([pool.submit(score_file, f) for f in files]):
            r = fu.result()
            if r:
                res.append(r)
    for lang, pfx in (("EN", "ws_en_"), ("ZH", "ws_zh_")):
        rr = [r for r in res if r[0].startswith(pfx)]
        if rr:
            item, row, ht, p4, n, npr = agg(rr)
            out[f"{name}_{lang}"] = dict(f1_item=item, f1_row=row, has_table=ht,
                                         pass4=p4, n=n, nprompt=npr)

json.dump(out, open(os.path.join(EVAL, "controlled_scores_v3.json"), "w"), indent=1)
print("\n\n===SUMMARY=== model lang | f1_item f1_row has_table pass@4 | n nprompt")
for k, v in out.items():
    name, lang = k.rsplit("_", 1)
    print(f"===ROW=== {name:8s} {lang} | {v['f1_item']:.3f} {v['f1_row']:.3f} "
          f"{v['has_table']:.2f} {v['pass4']:.3f} | {v['n']} {v['nprompt']}")
print("===DONE===")
