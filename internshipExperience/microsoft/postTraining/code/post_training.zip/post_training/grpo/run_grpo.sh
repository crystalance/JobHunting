#!/usr/bin/env bash
# Tiny GRPO smoke run for the WideSearch multi-turn tool agent (design Step 4).
# 2 prompts, group size 4, a couple of steps — validates the full loop
# (sglang multi-turn + hermes tool-calls + our execute_python tool + WideSearch
# reward + GRPO update) end-to-end before scaling.
#
# Run with the verl-multiturn-rollout env from the repo root:
#   bash post_training/grpo/run_grpo.sh
set -euo pipefail

REPO=/home/dkidna/WebSearchResearch
PY=/home/dkidna/miniconda3/envs/verl-multiturn-rollout/bin/python
cd "$REPO"

export WIDESEARCH_ROOT=/home/dkidna/WideSearch
export PYTHONPATH="$REPO:${PYTHONPATH:-}"
# Search throttle + budget (reused harness knobs) to bound Azure load per rollout.
export SEARCH_MAX_WORKERS=${SEARCH_MAX_WORKERS:-4}
export SEARCH_MAX_QUERIES_PER_CALL=${SEARCH_MAX_QUERIES_PER_CALL:-20}
export SEARCH_EPISODE_BUDGET=${SEARCH_EPISODE_BUDGET:-40}
# Shared on-disk summary cache: dedup identical queries across the G rollouts of
# a group and across steps (each rollout kernel is a separate process). Absolute
# path — kernels chdir into their workspace. Persists across runs (cost saver).
export SEARCH_CACHE_DIR=${SEARCH_CACHE_DIR:-$REPO/post_training/grpo/search_cache}

DATA=post_training/grpo/data
ACTOR=post_training/grpo/actor_init_v2
TOOLS=post_training/grpo/tools.yaml
REWARD=post_training/grpo/widesearch_reward.py
AGENT_LOOP=post_training/grpo/agent_loop_config.yaml

"$PY" -m verl.trainer.main_ppo \
  algorithm.adv_estimator=grpo \
  data.train_files="$DATA/tiny.parquet" \
  data.val_files="$DATA/tiny.parquet" \
  data.train_batch_size=2 \
  data.max_prompt_length=3072 \
  data.max_response_length=20480 \
  data.return_raw_chat=true \
  actor_rollout_ref.model.path="$ACTOR" \
  actor_rollout_ref.actor.strategy=fsdp2 \
  actor_rollout_ref.ref.strategy=fsdp2 \
  actor_rollout_ref.actor.optim.lr=1e-6 \
  actor_rollout_ref.actor.ppo_mini_batch_size=2 \
  actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.rollout.name=sglang \
  actor_rollout_ref.rollout.mode=async \
  actor_rollout_ref.rollout.n=4 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.55 \
  actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
  actor_rollout_ref.rollout.multi_turn.enable=true \
  actor_rollout_ref.rollout.multi_turn.format=hermes \
  actor_rollout_ref.rollout.multi_turn.max_assistant_turns=25 \
  actor_rollout_ref.rollout.multi_turn.max_tool_response_length=8192 \
  actor_rollout_ref.rollout.multi_turn.tool_config_path="$TOOLS" \
  actor_rollout_ref.rollout.agent.agent_loop_config_path="$AGENT_LOOP" \
  algorithm.kl_ctrl.kl_coef=0.001 \
  custom_reward_function.path="$REWARD" \
  custom_reward_function.name=compute_score \
  reward_model.launch_reward_fn_async=true \
  trainer.n_gpus_per_node=4 \
  trainer.nnodes=1 \
  trainer.total_epochs=1 \
  trainer.total_training_steps=2 \
  trainer.save_freq=-1 \
  trainer.test_freq=-1 \
  trainer.rollout_data_dir=post_training/grpo/rollout_dumps/train \
  trainer.validation_data_dir=post_training/grpo/rollout_dumps/val \
  trainer.project_name=widesearch_grpo \
  trainer.experiment_name=tiny_smoke \
  trainer.logger=console \
  "$@"
