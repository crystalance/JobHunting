"""
Offline scorer for the controlled checkpoint eval.

The harness `--stage eval` only scores single-sample `{iid}_response.jsonl`; with
`--num_samples 4` the responses are `{iid}__t{n}_response.jsonl`, so auto-scoring
skipped them. This scores every response with the real WideSearch evaluator
(gpt-4.1 judge for free-text cols) and aggregates per model:
  - mean f1_item / f1_row over all 4 samples x 14 prompts (average-case)
  - per-prompt mean then averaged (same thing, prompt-weighted)
  - pass@4 (best of 4 samples per prompt)

Run with the harness python:
  .venv-harness/bin/python post_training/grpo/score_eval_responses.py <eval_dir>
"""
import glob
import json
import os
import re
import sys
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from statistics import mean, pstdev

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from post_training.grpo import widesearch_reward as R  # reuses eval + Azure judge patch

MODELS = ["sft_init", "step_20", "step_25", "step_30"]


def score_file(path):
    m = re.match(r"(ws_en_\d+)__t(\d+)_response\.jsonl$", os.path.basename(path))
    if not m:
        return None
    iid, trial = m.group(1), int(m.group(2))
    try:
        obj = json.loads(open(path).readline())
        resp = obj.get("response", "") or ""
    except Exception:
        resp = ""
    f1_row, f1_item = R._score_response(iid, resp)
    return (iid, trial, f1_row, f1_item)


def main():
    eval_dir = sys.argv[1]
    models = sys.argv[2:] or MODELS
    R._lazy_init()
    print(f"{'model':10s} | {'f1_item':>8s} | {'f1_row':>7s} | {'pass@4_item':>11s} | {'has_table':>9s}")
    print("-" * 60)
    all_rows = {}
    for name in models:
        files = sorted(glob.glob(os.path.join(eval_dir, name, "*__t*_response.jsonl")))
        if not files:
            print(f"{name:10s} | (no files)")
            continue
        results = []
        with ThreadPoolExecutor(max_workers=8) as pool:
            futs = [pool.submit(score_file, f) for f in files]
            for fu in as_completed(futs):
                r = fu.result()
                if r:
                    results.append(r)
        # per-prompt aggregation
        by_prompt_item = defaultdict(list)
        by_prompt_row = defaultdict(list)
        for iid, trial, fr, fi in results:
            by_prompt_item[iid].append(fi)
            by_prompt_row[iid].append(fr)
        # average-case: mean over samples, then mean over prompts
        item_mean = mean([mean(v) for v in by_prompt_item.values()])
        row_mean = mean([mean(v) for v in by_prompt_row.values()])
        pass4 = mean([max(v) for v in by_prompt_item.values()])
        has_table = mean([1.0 if fi > 0 or fr > 0 else 0.0 for _, _, fr, fi in results])
        all_rows[name] = dict(f1_item=item_mean, f1_row=row_mean, pass4=pass4,
                              has_table=has_table, n=len(results),
                              per_prompt={k: mean(v) for k, v in by_prompt_item.items()})
        print(f"{name:10s} | {item_mean:8.3f} | {row_mean:7.3f} | {pass4:11.3f} | {has_table:9.2f}")
    with open(os.path.join(eval_dir, "controlled_scores.json"), "w") as f:
        json.dump(all_rows, f, indent=1)
    print(f"\nsaved -> {eval_dir}/controlled_scores.json")
    # delta vs sft_init
    if "sft_init" in all_rows:
        base = all_rows["sft_init"]["f1_item"]
        print(f"\nvs sft_init (f1_item {base:.3f}):")
        for name in models:
            if name in all_rows and name != "sft_init":
                d = all_rows[name]["f1_item"] - base
                print(f"  {name}: {all_rows[name]['f1_item']:.3f}  ({d:+.3f}, {100*d/max(base,1e-9):+.0f}%)")


if __name__ == "__main__":
    main()
