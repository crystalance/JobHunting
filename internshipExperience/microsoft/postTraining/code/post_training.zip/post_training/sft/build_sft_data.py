"""Convert saved agent trajectories (agent_trace.json) into SFT training records
with correct assistant-only loss masks.

Produces, per kept trajectory:
  - input_ids: full conversation rendered with the Qwen2.5 chat template (+tools)
  - labels:    input_ids on assistant spans, -100 elsewhere (loss-masked)

Loss-mask method: incremental prefix rendering. Chat templates are prefix-
consistent (appending a message only appends tokens), so the token span of the
assistant message at index k is:
    render(messages[:k+1]) minus the prefix render(messages[:k])
Those delta tokens get real labels; everything else is -100. This makes the model
learn to emit exactly the assistant turns (tool_calls rendered as
<tool_call>{...}</tool_call>, plus the final text) in the SAME format the vLLM
server parses.

Run with a python that has `transformers` (e.g. conda new_verl):
    /home/dkidna/miniconda3/envs/new_verl/bin/python post_training/sft/build_sft_data.py --selftest
"""
from __future__ import annotations
import argparse
import glob
import json
import os
import sys
from typing import Any

from transformers import AutoTokenizer

MODEL = "Qwen/Qwen2.5-7B-Instruct"
IGNORE = -100
MAX_LEN = 28672  # 32k - headroom (student window filter)

# Tool schema must match the serving harness (search_agent._EXECUTE_PYTHON_TOOL).
TOOLS = [{
    "type": "function",
    "function": {
        "name": "execute_python",
        "description": (
            "Execute Python code in a persistent IPython kernel. The kernel has "
            "`search_client` (with a `.search(query)` method) and `WORKSPACE` "
            "(str, cwd) pre-loaded. You can only see values that are printed to "
            "stdout. Always print() any value you need to inspect."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "thought": {"type": "string", "description": "Your reasoning for this step."},
                "code": {"type": "string", "description": "The Python code to execute."},
            },
            "required": ["thought", "code"],
        },
    },
}]

_TOK = None


def tok():
    global _TOK
    if _TOK is None:
        _TOK = AutoTokenizer.from_pretrained(MODEL)
    return _TOK


def _render_ids(messages: list[dict], add_gen: bool = False) -> list[int]:
    return tok().apply_chat_template(
        messages, tools=TOOLS, tokenize=True, add_generation_prompt=add_gen)


def build_example(conversation: list[dict]) -> dict[str, Any] | None:
    """Return {input_ids, labels, n_loss_tokens} or None if unrenderable."""
    # Normalize: assistant tool_calls must carry function.arguments as a JSON
    # OBJECT (dict), not a string. The OpenAI SDK / agent_trace stores arguments
    # as a string; if we pass the string to the template it renders an escaped
    # string ("arguments": "{\"...\"}"), which does NOT match the native tool-call
    # format the model emits / the parser reads. Parsing to a dict makes the
    # template render "arguments": {"thought":..., "code":...} (correct).
    msgs = []
    for m in conversation:
        role = m.get("role")
        nm = {"role": role}
        if m.get("content") is not None:
            nm["content"] = m["content"]
        if m.get("tool_calls"):
            tcs = []
            for tc in m["tool_calls"]:
                fn = dict(tc.get("function", {}))
                args = fn.get("arguments")
                if isinstance(args, str):
                    try:
                        fn["arguments"] = json.loads(args)
                    except Exception:
                        pass  # leave as-is if unparseable
                tcs.append({"id": tc.get("id"), "type": "function", "function": fn})
            nm["tool_calls"] = tcs
        if role == "tool":
            nm["tool_call_id"] = m.get("tool_call_id")
            nm["content"] = m.get("content", "")
        msgs.append(nm)

    try:
        full_ids = _render_ids(msgs)
    except Exception as e:  # noqa: BLE001
        print("  render failed:", str(e)[:120])
        return None

    labels = [IGNORE] * len(full_ids)
    # Walk prefixes; mark assistant message spans as loss-on.
    prev_len = len(_render_ids(msgs[:1])) if msgs else 0
    for k in range(1, len(msgs) + 1):
        ids_k = _render_ids(msgs[:k])
        span_start, span_end = prev_len, len(ids_k)
        if msgs[k - 1].get("role") == "assistant":
            # sanity: prefix consistency
            if ids_k[:prev_len] == full_ids[:prev_len]:
                for i in range(span_start, min(span_end, len(labels))):
                    labels[i] = full_ids[i]
        prev_len = len(ids_k)

    n_loss = sum(1 for x in labels if x != IGNORE)
    return {"input_ids": full_ids, "labels": labels,
            "n_tokens": len(full_ids), "n_loss_tokens": n_loss}


def _selftest():
    candidates = [
        "search_agent/batch_results/gpt54_ws_en_028/ws_en_028/agent_trace.json",
        "search_agent/batch_results/gpt41_ws_en_028/ws_en_028/agent_trace.json",
    ]
    path = next((c for c in candidates if os.path.exists(c)), None)
    assert path, "no trace found for selftest"
    print("selftest trace:", path)
    conv = json.load(open(path))["conversation"]
    ex = build_example(conv)
    assert ex, "build failed"
    print("n_tokens=%d  n_loss_tokens=%d  (%.1f%% loss-on)" % (
        ex["n_tokens"], ex["n_loss_tokens"], 100 * ex["n_loss_tokens"] / ex["n_tokens"]))
    assert ex["n_tokens"] <= MAX_LEN, "exceeds student window"
    assert ex["n_loss_tokens"] > 0, "no loss tokens!"
    # Decode the loss-on tokens and confirm they contain tool calls + final answer.
    loss_ids = [i for i, l in zip(ex["input_ids"], ex["labels"]) if l != IGNORE]
    decoded = tok().decode(loss_ids)
    print("--- decoded LOSS-ON tokens (first 500 chars) ---")
    print(decoded[:500])
    assert "<tool_call>" in decoded, "expected tool_call in loss-on span"
    print("\n--- checks ---")
    print("has <tool_call> in loss-on:", "<tool_call>" in decoded)
    print("has execute_python in loss-on:", "execute_python" in decoded)
    print("SELFTEST PASSED")


def _select_from_scores(args):
    """Trial-aware rejection-sampling selection from a per-trial scores.jsonl.

    Applies behavioural gates + F1 floors, optional LLM-judge keep, then keeps
    the top-N trajectories per instance (ranked correctness-then-efficiency) and
    tokenizes them into the SFT JSONL.
    """
    from collections import defaultdict
    rows = [json.loads(l) for l in open(args.scores) if l.strip()]

    keep_set = None
    if args.verdicts and os.path.exists(args.verdicts):
        keep_set = {(v["instance_id"], v["trial"])
                    for v in (json.loads(l) for l in open(args.verdicts) if l.strip())
                    if v.get("keep")}
        print("LLM-judge keep set: %d rollouts" % len(keep_set))

    by_inst = defaultdict(list)
    gate_drop = 0
    for r in rows:
        ok = (r.get("has_output") and r.get("converged") and not r.get("looped")
              and r.get("err_rate", 1.0) <= args.err_max and not r.get("eval_err")
              and r.get("f1_row", 0.0) >= args.tau and r.get("f1_item", 0.0) >= args.tau_item)
        if keep_set is not None and (r["instance_id"], r["trial"]) not in keep_set:
            ok = False
        if not ok:
            gate_drop += 1
            continue
        by_inst[r["instance_id"]].append(r)

    selected = []
    for iid, rs in by_inst.items():
        # correctness first, then efficiency (fewer searches/turns)
        rs.sort(key=lambda r: (-r.get("f1_row", 0.0), -r.get("f1_item", 0.0),
                               r.get("n_searches", 1e9), r.get("n_turns", 1e9)))
        selected += rs[:args.top_n]

    kept = dropped = 0
    with open(args.out, "w") as f:
        for r in selected:
            tp = os.path.join(r["run_dir"], "agent_trace.json")
            if not os.path.exists(tp):
                dropped += 1
                print("DROP %s__t%s no trace" % (r["instance_id"], r["trial"]))
                continue
            conv = json.load(open(tp)).get("conversation", [])
            final = conv[-1] if conv else {}
            completed = final.get("role") == "assistant" and bool(final.get("content"))
            ex = build_example(conv) if completed else None
            reason = None
            if not completed:
                reason = "no final answer"
            elif ex is None:
                reason = "render fail"
            elif ex["n_tokens"] > MAX_LEN:
                reason = "too long (%d tok)" % ex["n_tokens"]
            if reason:
                dropped += 1
                print("DROP %s__t%s %s" % (r["instance_id"], r["trial"], reason))
                continue
            ex["instance_id"] = r["instance_id"]
            ex["trial"] = r["trial"]
            ex["f1_row"] = r.get("f1_row")
            ex["f1_item"] = r.get("f1_item")
            f.write(json.dumps(ex) + "\n")
            kept += 1
            print("KEEP %s__t%s f1_row=%.2f f1_item=%.2f n_tok=%d loss=%d" % (
                r["instance_id"], r["trial"], r.get("f1_row", 0), r.get("f1_item", 0),
                ex["n_tokens"], ex["n_loss_tokens"]))
    print("\nKEPT %d  DROPPED %d (+%d gated)  from %d instances (top_n=%d) -> %s" % (
        kept, dropped, gate_drop, len(by_inst), args.top_n, args.out))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--out", type=str, default=None, help="output JSONL (tokenized)")
    ap.add_argument("--results_root", type=str, nargs="+", default=None,
                    help="one or more dirs each containing <instance>/agent_trace.json + summary.json")
    ap.add_argument("--tau", type=float, default=0.0, help="min f1_by_row to keep")
    ap.add_argument("--tau_item", type=float, default=0.5,
                    help="min f1_by_item to keep (cold-start quality floor)")
    ap.add_argument("--scores", type=str, default=None,
                    help="per-trial scores.jsonl (from score_trajectories); enables "
                         "trial-aware rejection-sampling selection with behavioural gates.")
    ap.add_argument("--top_n", type=int, default=2,
                    help="with --scores: max trajectories kept per instance.")
    ap.add_argument("--err_max", type=float, default=0.2,
                    help="with --scores: max tool-error rate to keep.")
    ap.add_argument("--verdicts", type=str, default=None,
                    help="optional verdicts.jsonl (LLM judge); if given, drop rollouts with keep=false.")
    args = ap.parse_args()

    if args.selftest:
        _selftest()
        return

    if args.scores:
        _select_from_scores(args)
        return

    assert args.results_root and args.out, "need --results_root and --out"
    scores = {}
    traces = []
    for root in args.results_root:
        sp = os.path.join(root, "summary.json")
        if os.path.exists(sp):
            for r in json.load(open(sp)).get("per_query", []):
                scores[r["instance_id"]] = (r.get("f1_row", 0.0), r.get("f1_item", 0.0))
        traces += sorted(glob.glob(os.path.join(root, "*", "agent_trace.json")))

    kept = dropped = 0
    with open(args.out, "w") as f:
        for tp in traces:
            iid = os.path.basename(os.path.dirname(tp))
            conv = json.load(open(tp)).get("conversation", [])
            f1, f1_item = scores.get(iid, (None, None))
            final = conv[-1] if conv else {}
            completed = final.get("role") == "assistant" and bool(final.get("content"))
            ex = build_example(conv) if completed else None
            reason = None
            if not completed:
                reason = "no final answer"
            elif ex is None:
                reason = "render fail"
            elif ex["n_tokens"] > MAX_LEN:
                reason = "too long (%d tok)" % ex["n_tokens"]
            elif f1 is not None and f1 < args.tau:
                reason = "f1_row %.2f < tau" % f1
            elif f1_item is not None and f1_item < args.tau_item:
                reason = "f1_item %.2f < tau_item" % f1_item
            if reason:
                dropped += 1
                print("DROP %-12s %s" % (iid, reason))
                continue
            ex["instance_id"] = iid
            ex["f1_row"] = f1
            ex["f1_item"] = f1_item
            f.write(json.dumps(ex) + "\n")
            kept += 1
            print("KEEP %-12s f1_row=%s f1_item=%s n_tok=%d loss=%d" % (iid, f1, f1_item, ex["n_tokens"], ex["n_loss_tokens"]))
    print("\nKEPT %d  DROPPED %d  -> %s" % (kept, dropped, args.out))


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    main()
