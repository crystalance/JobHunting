"""
Build verl GRPO parquet datasets for WideSearch multi-turn tool RL.

Each row = one WideSearch prompt. Columns follow verl's multi-turn tool format:
  - prompt            : chat messages [system=frozen SFT prompt, user=task]
  - data_source       : "widesearch"  (routes to our reward)
  - agent_name        : "widesearch_tool_agent"  (persistent-env tool loop)
  - reward_model      : {"style":"rule", "ground_truth": <instance_id>}
  - extra_info        : {instance_id, index, need_tools_kwargs, tools_kwargs{execute_python:{create_kwargs}}}

Run with the harness venv (needs WideSearch loader):
  .venv-harness/bin/python -m post_training.grpo.build_grpo_parquet \
      --split train --out post_training/grpo/data/train.parquet
  ... --split val   --out post_training/grpo/data/val.parquet
  ... --instance_ids ws_en_001,ws_en_002 --out .../tiny.parquet   # tiny run
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from search_agent.search_agent import _SYSTEM_PROMPT
from search_agent.batch_eval import load_widesearch_queries

_FINAL_HINT = (
    "\n\nIMPORTANT: In your FINAL text answer, include the COMPLETE result table "
    "in markdown so it can be graded, in addition to writing it to output/."
)

TRAIN = [f"ws_en_{i:03d}" for i in range(1, 71)]
VAL = [f"ws_en_{i:03d}" for i in range(71, 86) if i != 79]


def build(instance_ids, widesearch_root, out_path):
    import pandas as pd
    queries = load_widesearch_queries(Path(widesearch_root), instance_ids, None)
    rows = []
    for idx, q in enumerate(queries):
        iid = q.instance_id
        user = q.query + _FINAL_HINT
        rows.append({
            "data_source": "widesearch",
            "agent_name": "widesearch_tool_agent",
            "prompt": [
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": user},
            ],
            "reward_model": {"style": "rule", "ground_truth": iid},
            "extra_info": {
                "instance_id": iid,
                "index": idx,
                "need_tools_kwargs": True,
                "tools_kwargs": {
                    "execute_python": {
                        "create_kwargs": {"instance_id": iid, "ground_truth": iid},
                    },
                },
            },
        })
    df = pd.DataFrame(rows)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    df.to_parquet(out_path)
    print(f"wrote {len(df)} rows -> {out_path}")
    print("instances:", [r['extra_info']['instance_id'] for r in rows][:10],
          "..." if len(rows) > 10 else "")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", choices=["train", "val"], default=None)
    ap.add_argument("--instance_ids", type=str, default=None,
                    help="comma-separated ws_en_### (overrides --split)")
    ap.add_argument("--widesearch_root", default=os.getenv("WIDESEARCH_ROOT", "/home/dkidna/WideSearch"))
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    if args.instance_ids:
        ids = [x.strip() for x in args.instance_ids.split(",") if x.strip()]
    elif args.split == "train":
        ids = TRAIN
    elif args.split == "val":
        ids = VAL
    else:
        raise SystemExit("need --split or --instance_ids")
    build(ids, args.widesearch_root, args.out)


if __name__ == "__main__":
    main()
