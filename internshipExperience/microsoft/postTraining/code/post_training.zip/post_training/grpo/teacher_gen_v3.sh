#!/usr/bin/env bash
# Teacher generation v3 for SFT data — gpt-5.4 reasoning + gpt-4.1-mini search,
# with the enumerate-then-loop system prompt, over EN+ZH train (001-070 each).
# Sharded parallel (run_infer is serial, so N disjoint shards run concurrently;
# all Azure API, no GPU). Each shard writes its own output_root; the SFT builder
# reads across all shards. --stage both auto-scores (num_samples=1 layout).
#
#   bash post_training/grpo/teacher_gen_v3.sh          # N=5 shards
#   N=7 bash post_training/grpo/teacher_gen_v3.sh
set -uo pipefail

REPO=/home/dkidna/WebSearchResearch
HARNESS=$REPO/.venv-harness/bin/python
cd "$REPO"

export WIDESEARCH_ROOT=/home/dkidna/WideSearch
export PYTHONPATH="$REPO"
export SEARCH_CACHE_DIR=$REPO/post_training/grpo/search_cache   # warmed, shared
export SEARCH_MAX_WORKERS=${SEARCH_MAX_WORKERS:-3}              # x N shards -> keep Azure sane
export SEARCH_MAX_QUERIES_PER_CALL=${SEARCH_MAX_QUERIES_PER_CALL:-20}
export SEARCH_EPISODE_BUDGET=${SEARCH_EPISODE_BUDGET:-80}       # teacher does wide fan-out

OUT=$REPO/post_training/grpo/teacher_gen_v3
mkdir -p "$OUT"
N=${N:-5}
NS=${NS:-4}   # samples per case (rejection-sampling depth); build step selects top-N/case

mapfile -t SHARDS < <(python3 -c "
ids=[f'ws_en_{i:03d}' for i in range(1,71)]+[f'ws_zh_{i:03d}' for i in range(1,71)]
N=$N
for s in range(N): print(','.join(ids[s::N]))
")

echo "launching $N shards -> $OUT"
PIDS=()
for i in "${!SHARDS[@]}"; do
  "$HARNESS" search_agent/batch_eval.py --stage both --instance_ids "${SHARDS[$i]}" \
    --reasoning_model gpt-5.4 --search_model gpt-4.1-mini --num_samples "$NS" \
    --output_root "$OUT/shard_$i" > "$OUT/shard_$i.log" 2>&1 &
  PIDS+=($!)
  echo "  shard $i: $(echo ${SHARDS[$i]} | tr ',' ' ' | wc -w) instances (pid $!)"
done

FAIL=0
for p in "${PIDS[@]}"; do wait "$p" || FAIL=1; done
echo "TEACHER GEN v3 DONE (fail=$FAIL) -> $OUT"
