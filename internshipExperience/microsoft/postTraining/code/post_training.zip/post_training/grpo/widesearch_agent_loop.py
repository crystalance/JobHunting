"""
Persistent-environment agent loop for the WideSearch code-act agent under verl.

verl's default ToolAgentLoop does `create -> execute -> release` per tool call,
so the IPython kernel + workspace do NOT persist across turns (state and the
output file are lost every turn). That mismatches the SFT training environment
(a persistent notebook kernel) and breaks output-file accumulation.

This subclass assigns ONE stable id per rollout and injects it into every tool's
`create_kwargs["_rollout_id"]`. Our ExecutePythonTool uses that id to keep a
single kernel + workspace alive for the whole rollout (reused across turns) and
tears it down once, at episode end, via `release_rollout`.

Registered via agent_loop_config (name: widesearch_tool_agent). Point the data's
`agent_name` at "widesearch_tool_agent".
"""
from __future__ import annotations

import copy
import logging
import os
import sys
from uuid import uuid4

# make post_training importable in the ray workers
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from verl.experimental.agent_loop.agent_loop import register
from verl.experimental.agent_loop.tool_agent_loop import ToolAgentLoop

logger = logging.getLogger(__file__)


@register("widesearch_tool_agent")
class WideSearchToolAgentLoop(ToolAgentLoop):
    async def run(self, sampling_params, **kwargs):
        rollout_id = uuid4().hex
        # Deep-copy tools_kwargs so the G concurrent rollouts of the same prompt
        # (which share the data row's tools_kwargs dict) don't race when we
        # inject a per-rollout id.
        tk = copy.deepcopy(kwargs.get("tools_kwargs", {}) or {})
        for tconf in tk.values():
            if isinstance(tconf, dict):
                tconf.setdefault("create_kwargs", {})["_rollout_id"] = rollout_id
        kwargs = {**kwargs, "tools_kwargs": tk}
        try:
            return await super().run(sampling_params, **kwargs)
        finally:
            for tname in list(tk.keys()):
                tool = self.tools.get(tname)
                if tool is not None and hasattr(tool, "release_rollout"):
                    try:
                        await tool.release_rollout(rollout_id)
                    except Exception as e:  # noqa: BLE001
                        logger.warning("release_rollout(%s) failed: %s", tname, e)
