#!/usr/bin/env bash
# GRPO v3 run: "gentle polish" on top of the strong SFT-v3 policy.
# Applies the 7/15 collapse lessons + the 7/20 reward redesign:
#   - init from actor_init_v3 (high-coverage SFT), NOT actor_init_v2.
#   - reward v3 (widesearch_reward.py defaults): f1_item 1.0, f1_row 0.8,
#     has_table 0.1, turn-cost REMOVED (W_COST=0), hard no-table floor -0.1.
#   - KL 0.005 (between v1's 0.001 and the over-tight v2's 0.01) to anchor to
#     the already-efficient v3 policy without over-constraining.
#   - save/test every 3 steps, keep last 2 (disk-bounded); watch val f1 &
#     has_table in rollout_dumps_v3/val to pick the best-by-val checkpoint.
#   - NEW ckpt + dump dirs so actor_init_v3 and merged/step_30 are preserved.
#
#   bash post_training/grpo/run_grpo_v3.sh
set -euo pipefail

REPO=/home/dkidna/WebSearchResearch
PY=/home/dkidna/miniconda3/envs/verl-multiturn-rollout/bin/python
cd "$REPO"

export WIDESEARCH_ROOT=/home/dkidna/WideSearch
export PYTHONPATH="$REPO:${PYTHONPATH:-}"
export SEARCH_MAX_WORKERS=${SEARCH_MAX_WORKERS:-4}
export SEARCH_MAX_QUERIES_PER_CALL=${SEARCH_MAX_QUERIES_PER_CALL:-20}
export SEARCH_EPISODE_BUDGET=${SEARCH_EPISODE_BUDGET:-60}
export SEARCH_CACHE_DIR=${SEARCH_CACHE_DIR:-$REPO/post_training/grpo/search_cache}

# Reward v3 is the file default (W_COST=0, W_OUT=0.1, no-table floor -0.1); the
# lines below are explicit so the run is self-documenting / overridable.
export GRPO_W_ITEM=${GRPO_W_ITEM:-1.0}
export GRPO_W_ROW=${GRPO_W_ROW:-0.8}
export GRPO_W_OUT=${GRPO_W_OUT:-0.1}
export GRPO_W_COST=${GRPO_W_COST:-0.0}
export GRPO_W_FAB=${GRPO_W_FAB:-0.1}
export GRPO_NO_TABLE_FLOOR=${GRPO_NO_TABLE_FLOOR:--0.1}

DATA=post_training/grpo/data
ACTOR=post_training/grpo/actor_init_v3
TOOLS=post_training/grpo/tools.yaml
REWARD=post_training/grpo/widesearch_reward.py
AGENT_LOOP=post_training/grpo/agent_loop_config.yaml
CKPT=post_training/grpo/checkpoints/train_v3

"$PY" -m verl.trainer.main_ppo \
  algorithm.adv_estimator=grpo \
  data.train_files="$DATA/train.parquet" \
  data.val_files="$DATA/val.parquet" \
  data.train_batch_size=8 \
  data.max_prompt_length=3072 \
  data.max_response_length=20480 \
  data.return_raw_chat=true \
  actor_rollout_ref.model.path="$ACTOR" \
  actor_rollout_ref.actor.strategy=fsdp2 \
  actor_rollout_ref.ref.strategy=fsdp2 \
  actor_rollout_ref.actor.optim.lr=1e-6 \
  actor_rollout_ref.actor.ppo_mini_batch_size=8 \
  actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.rollout.name=sglang \
  actor_rollout_ref.rollout.mode=async \
  actor_rollout_ref.rollout.n=8 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.55 \
  actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
  actor_rollout_ref.rollout.multi_turn.enable=true \
  actor_rollout_ref.rollout.multi_turn.format=hermes \
  actor_rollout_ref.rollout.multi_turn.max_assistant_turns=25 \
  actor_rollout_ref.rollout.multi_turn.max_tool_response_length=8192 \
  actor_rollout_ref.rollout.multi_turn.tool_config_path="$TOOLS" \
  actor_rollout_ref.rollout.agent.agent_loop_config_path="$AGENT_LOOP" \
  algorithm.kl_ctrl.kl_coef=0.005 \
  custom_reward_function.path="$REWARD" \
  custom_reward_function.name=compute_score \
  reward_model.launch_reward_fn_async=true \
  trainer.n_gpus_per_node=4 \
  trainer.nnodes=1 \
  trainer.total_epochs=100 \
  trainer.total_training_steps=21 \
  trainer.save_freq=3 \
  trainer.test_freq=3 \
  trainer.max_actor_ckpt_to_keep=2 \
  trainer.default_local_dir="$CKPT" \
  trainer.rollout_data_dir=post_training/grpo/rollout_dumps_v3/train \
  trainer.validation_data_dir=post_training/grpo/rollout_dumps_v3/val \
  trainer.project_name=widesearch_grpo \
  trainer.experiment_name=train_v3 \
  trainer.logger=console \
  "$@"
