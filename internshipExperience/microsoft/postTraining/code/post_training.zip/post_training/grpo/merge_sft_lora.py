"""Merge the SFT LoRA adapter (ckpt_train_v2) into Qwen2.5-7B-Instruct to produce
a full-parameter HF checkpoint for the verl GRPO actor init.

Run with the new_verl env (has peft + transformers):
  /home/dkidna/miniconda3/envs/new_verl/bin/python \
      post_training/grpo/merge_sft_lora.py \
      --adapter post_training/sft/ckpt_train_v2 \
      --out post_training/grpo/actor_init_v2
"""
import argparse

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="Qwen/Qwen2.5-7B-Instruct")
    ap.add_argument("--adapter", default="post_training/sft/ckpt_train_v2")
    ap.add_argument("--out", default="post_training/grpo/actor_init_v2")
    args = ap.parse_args()

    print(f"loading base {args.base} ...")
    base = AutoModelForCausalLM.from_pretrained(args.base, torch_dtype=torch.bfloat16)
    print(f"attaching + merging adapter {args.adapter} ...")
    model = PeftModel.from_pretrained(base, args.adapter)
    model = model.merge_and_unload()
    print(f"saving merged full model -> {args.out}")
    model.save_pretrained(args.out, safe_serialization=True)
    AutoTokenizer.from_pretrained(args.base).save_pretrained(args.out)
    print("done.")


if __name__ == "__main__":
    main()
