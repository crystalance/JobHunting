"""
Convert teacher_gen_v3/scores.json (f1 per (iid,trial) + trace path) into the
per-trial scores.jsonl format expected by build_sft_data.py --scores, by adding
behavioural fields computed from each agent_trace.json + search_log.

  .venv-harness/bin/python post_training/grpo/make_scores_jsonl.py <gen_dir>
"""
import glob
import json
import os
import re
import sys

GEN = sys.argv[1] if len(sys.argv) > 1 else "post_training/grpo/teacher_gen_v3"


def trace_stats(run_dir):
    tp = os.path.join(run_dir, "agent_trace.json")
    conv = json.load(open(tp)).get("conversation", [])
    n_turns = 0
    n_err = 0
    for m in conv:
        if m.get("role") == "assistant" and m.get("tool_calls"):
            n_turns += len(m["tool_calls"])
        if m.get("role") == "tool":
            c = str(m.get("content", ""))
            if "[error]" in c.lower() or "Traceback" in c or "SyntaxError" in c:
                n_err += 1
    final = conv[-1] if conv else {}
    has_output = final.get("role") == "assistant" and bool(final.get("content"))
    err_rate = (n_err / n_turns) if n_turns else 0.0
    n_searches = 0
    for slog in glob.glob(os.path.join(run_dir, "workspace", "log", "*", "search_log.json")):
        try:
            logs = json.load(open(slog))
            n_searches += len(logs) if isinstance(logs, list) else 0
        except Exception:
            pass
    return dict(n_turns=n_turns, n_searches=n_searches, err_rate=err_rate,
                has_output=bool(has_output), converged=bool(has_output) and n_turns < 60,
                looped=False, eval_err=False)


def main():
    scores = json.load(open(os.path.join(GEN, "scores.json")))
    out = os.path.join(GEN, "scores.jsonl")
    n = 0
    with open(out, "w") as f:
        for r in scores:
            run_dir = os.path.dirname(r["trace"])
            if not os.path.exists(os.path.join(run_dir, "agent_trace.json")):
                continue
            try:
                st = trace_stats(run_dir)
            except Exception:
                continue
            row = {"instance_id": r["iid"], "trial": r["trial"], "run_dir": run_dir,
                   "f1_row": r["f1_row"], "f1_item": r["f1_item"], **st}
            f.write(json.dumps(row) + "\n")
            n += 1
    print(f"wrote {n} rows -> {out}")


if __name__ == "__main__":
    main()
