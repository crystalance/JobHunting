# Lessons — RL-first (v2-reward GRPO) policy collapse

**Date:** 2026-07-15
**Experiment:** "Can we improve RL to raise the score *before* doing new SFT?" —
GRPO from the existing SFT (`actor_init_v2`) with a redesigned reward (v2) + higher KL.
**Outcome:** ❌ **policy collapsed** after step 5. Clear, useful negative result.

---

## 1. What we tried & why

Motivation was real, not a whim:
- On held-out test, **pass@4 (0.49–0.52) ≫ mean (0.34)** → good answers already exist in
  the model's samples; RL's whole job is to close that gap. Worth a cheap attempt before
  the expensive teacher-distillation + SFT.
- 42% of rollouts already used enumerate-then-loop → a behavior RL could reinforce.

**Reward v2 (the changes):**
| term | v1 | v2 | intent |
|---|---|---|---|
| `f1_row` weight | 0.5 | **0.8** | reward coverage/recall (the score bottleneck) |
| `has_table` weight | 0.1 | **0.05** | stop rewarding "just finish" |
| turn budget | 20 (inert) | **12, active** | make efficiency deliberate |
| `num_turns` | never plumbed | **counted from `<tool_call>`** | turn-cost term actually fires |
| KL coef | 0.001 | **0.01** | stop the regression tax |

Init = same SFT; G=8; 30 steps; new checkpoint dir (step_30 preserved).

---

## 2. What happened — collapse

| step | f1_item | f1_row | has_table |
|---:|---:|---:|---:|
| 0 | 0.238 | 0.120 | 0.36 |
| 5 | **0.315** | 0.136 | 0.57 |
| 10 | 0.050 | 0.001 | 0.07 |
| 15–30 | **0.000** | 0.000 | **0.00** |

Improved at step 5, then **catastrophically collapsed** — by step 15 it writes **no table at all**.

**Failure mode (step-30 output):** the model emits **one** search tool-call (a valid
enumerate-then-loop `queries=[...]; search(queries)`) and then **stops** — no tool response,
no table written. Response length **halved** (10k → 4.9k chars).

---

## 3. Root cause

**The turn-cost term created a perverse "stop early" incentive.** With `num_turns` counted and
a tight budget (12), GRPO found it could cut the turn penalty by **emitting fewer turns** — and
over-optimized into "do one search, then stop." That produces no table (reward ≈ 0), but once
**every** rollout in the batch collapses to no-table, all rewards are ~equal → **advantage ≈ 0
→ no gradient to recover** → the policy is stuck in the degenerate basin. Reward-hacking →
length/entropy collapse.

The step-5→step-10 cliff is the signature: a threshold was crossed where short-output
trajectories started dominating, and there was no signal to climb back out.

---

## 4. Lessons (actionable)

1. **Do NOT reward "fewer turns" directly when turns are required to finish the task.**
   A turn penalty fights task completion. The −48% turn reduction in the *first* GRPO run was an
   **emergent, safe** side effect of chasing outcome reward — *forcing* it via an explicit cost
   term is unsafe. Let efficiency come from KL-anchored polish, not a completion-fighting penalty.

2. **Use best-by-val checkpointing for unstable RL, not keep-latest.**
   `max_actor_ckpt_to_keep=2` retained the **last two** (collapsed steps 25, 30) and **deleted the
   only good checkpoint (step 5, f1 0.315)**. For RL that can collapse, save the best-on-val
   checkpoint, or checkpoint more frequently and select afterward.

3. **Watch collapse signals live, add guardrails.** Response-length halving + `has_table`
   trending to 0 are early collapse tells. Track `actor/entropy`, response length, and val
   `has_table`; consider early-stop / KL bump / LR drop when they slide. A minimum-completion or
   format reward floor would have prevented the "no table" absorbing state.

4. **Change one thing at a time.** v2 bundled reward reshape + turn-cost + higher KL + new prompt.
   When it collapsed, the cause had to be *diagnosed* from the trajectory rather than *read off*.
   Ablate risky terms (esp. the turn cost) individually.

5. **Canonical order (SFT→RL) exists for a reason.** Trying to make RL *teach* capability (via a
   coverage reward) is fragile; RL is a *polish* step over behaviors the base policy already
   produces reliably. This result is evidence for teaching the pattern in **SFT** first.

---

## 5. What we did NOT lose

- **`step_30` (the original best model) is intact** — the run wrote to a separate dir
  (`train_v2reward`), so `train_scaled/global_step_30` + `merged/step_30` were untouched.
- Cost: ~3h45m compute + some Azure search. No artifacts of value lost.

---

## 6. Implication for next steps

- **RL-first is answered:** the pass@k headroom is real but **not safely capturable** with a
  reward push from this SFT. → proceed to **v3 SFT** (teach enumerate-then-loop in supervised
  learning; stable, no collapse risk; teacher pilot already validated at f1 0.82, 100% pattern).
- **If RL is revisited after v3 SFT:** drop the turn-cost term, recall-weight only (mild),
  KL ≈ 0.005, **best-by-val** checkpointing, and a completion/format reward floor to remove the
  no-table absorbing state.

**Config for reference:** `post_training/grpo/run_grpo_v2reward.sh`, reward
`post_training/grpo/widesearch_reward.py` (v2 defaults), val dumps
`post_training/grpo/rollout_dumps_v2reward/val/*.jsonl`, log `train_v2reward.log`.
