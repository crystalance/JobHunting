#!/usr/bin/env bash
# Controlled head-to-head eval of SFT-init vs GRPO checkpoints (step_20/25/30) on
# the val split, via the harness (real search on gpt-4.1-mini). Variance-reduced:
# num_samples>1 with temperature>0, and a SHARED warmed search cache so identical
# queries return identical results across all models. One vLLM server per GPU so
# the 4 models run in parallel (same wall-clock as one).
#
#   bash post_training/grpo/eval_checkpoints.sh          # full run
#   SMOKE=1 bash post_training/grpo/eval_checkpoints.sh  # 2 prompts, n=1 sanity
set -uo pipefail

REPO=/home/dkidna/WebSearchResearch
VBIN=/home/dkidna/miniconda3/envs/new_verl/bin
HARNESS=$REPO/.venv-harness/bin/python
cd "$REPO"

export WIDESEARCH_ROOT=/home/dkidna/WideSearch
export PYTHONPATH="$REPO"
export SEARCH_CACHE_DIR="$REPO/post_training/grpo/search_cache"   # warmed, shared, frozen-ish
export SEARCH_MAX_WORKERS=${SEARCH_MAX_WORKERS:-3}                # 4 models x 3 = 12 concurrent Azure search
export SEARCH_MAX_QUERIES_PER_CALL=${SEARCH_MAX_QUERIES_PER_CALL:-20}
export SEARCH_EPISODE_BUDGET=${SEARCH_EPISODE_BUDGET:-40}

VAL="ws_en_071,ws_en_072,ws_en_073,ws_en_074,ws_en_075,ws_en_076,ws_en_077,ws_en_078,ws_en_080,ws_en_081,ws_en_082,ws_en_083,ws_en_084,ws_en_085"
NS=4; TEMP=0.7
if [[ "${SMOKE:-0}" == "1" ]]; then VAL="ws_en_081,ws_en_083"; NS=1; fi
# Overridable from env: INSTANCES (comma list), NS (samples), TEMP, MODELS_SPEC
# (semicolon-separated "name|path|gpu|port" entries).
INSTANCES="${INSTANCES:-$VAL}"
NS="${NS_OVERRIDE:-$NS}"
TEMP="${TEMP_OVERRIDE:-$TEMP}"

STAMP=$(date +%Y%m%d_%H%M%S)
OUT="$REPO/post_training/grpo/eval_$STAMP"
mkdir -p "$OUT"
echo "output dir: $OUT"

# name|path|gpu|port  (override via MODELS_SPEC env, ';'-separated)
DEFAULT_MODELS="sft_init|post_training/grpo/actor_init_v2|0|8001;step_20|post_training/grpo/merged/step_20|1|8002;step_25|post_training/grpo/merged/step_25|2|8003;step_30|post_training/grpo/merged/step_30|3|8004"
IFS=';' read -r -a MODELS <<< "${MODELS_SPEC:-$DEFAULT_MODELS}"

PIDS=()
cleanup(){ echo "cleaning up servers..."; for p in "${PIDS[@]}"; do kill "$p" 2>/dev/null; done; }
trap cleanup EXIT

# 1) start one vLLM server per model on its own GPU
for m in "${MODELS[@]}"; do IFS='|' read -r name path gpu port <<< "$m"
  echo "serving $name on GPU $gpu port $port"
  CUDA_VISIBLE_DEVICES=$gpu "$VBIN/vllm" serve "$REPO/$path" \
    --served-model-name "$name" --port "$port" \
    --gpu-memory-utilization 0.85 --max-model-len 32768 \
    --enable-auto-tool-choice --tool-call-parser hermes \
    > "$OUT/serve_$name.log" 2>&1 &
  PIDS+=($!)
done

# 2) wait for all servers healthy (up to 8 min)
for m in "${MODELS[@]}"; do IFS='|' read -r name path gpu port <<< "$m"
  for i in $(seq 1 96); do
    if curl -sf "http://localhost:$port/v1/models" >/dev/null 2>&1; then echo "$name ready"; break; fi
    sleep 5
    if [[ $i == 96 ]]; then echo "ERROR: $name never became ready"; fi
  done
done

# 3) run the 4 harness evals in parallel (each serial internally)
EPIDS=()
for m in "${MODELS[@]}"; do IFS='|' read -r name path gpu port <<< "$m"
  echo "eval $name -> $OUT/$name"
  "$HARNESS" search_agent/batch_eval.py --stage both --instance_ids "$INSTANCES" \
    --reasoning_base_url "http://localhost:$port/v1" --reasoning_model "$name" \
    --reasoning_api_key EMPTY --search_model gpt-4.1-mini \
    --num_samples $NS --temperature $TEMP \
    --output_root "$OUT/$name" > "$OUT/eval_$name.log" 2>&1 &
  EPIDS+=($!)
done

# 4) wait for all evals
FAIL=0
for p in "${EPIDS[@]}"; do wait "$p" || FAIL=1; done
echo "ALL EVALS DONE (fail=$FAIL). Results under $OUT"
echo "$OUT" > "$REPO/post_training/grpo/.last_eval_dir"
