"""
Measure the code-act efficiency pattern in agent trajectories.

For each rollout (agent_trace.json + its workspace search_log.json), compute:
  - n_code_turns : # assistant execute_python turns (LLM round-trips = latency/cost)
  - n_searches   : total searches actually issued (ground truth from search_log.json)
  - batch_factor : n_searches / n_code_turns  (>1 = batched for-loop code-act;
                    ~1 = one-search-per-turn)
  - forloop      : any code block contains a `for` loop
  - list_search  : any `search_client.search([...])` (list-batched) call

Usage: python analyze_codeact.py <eval_dir> [model1 model2 ...]
"""
import glob
import json
import os
import re
import sys
from statistics import mean


def analyze_rollout(rollout_dir):
    trace_p = os.path.join(rollout_dir, "agent_trace.json")
    if not os.path.exists(trace_p):
        return None
    try:
        conv = json.load(open(trace_p)).get("conversation", [])
    except Exception:
        return None
    codes = []
    for m in conv:
        if m.get("role") == "assistant" and m.get("tool_calls"):
            for tc in m["tool_calls"]:
                try:
                    args = tc["function"]["arguments"]
                    args = json.loads(args) if isinstance(args, str) else args
                    codes.append(str(args.get("code", "")))
                except Exception:
                    pass
    n_turns = len(codes)
    allcode = "\n".join(codes)
    forloop = bool(re.search(r"\bfor\b .*\bin\b", allcode))
    list_search = bool(re.search(r"search_client\.search\s*\(\s*\[", allcode)) or \
        bool(re.search(r"search_client\.search\s*\(\s*\w+\s*\)", allcode))  # search(var) often a list
    # ground-truth search count from search_log.json
    n_searches = 0
    for slog in glob.glob(os.path.join(rollout_dir, "workspace", "log", "*", "search_log.json")):
        try:
            logs = json.load(open(slog))
            n_searches += len(logs) if isinstance(logs, list) else 0
        except Exception:
            pass
    return dict(n_turns=n_turns, n_searches=n_searches, forloop=forloop, list_search=list_search)


def main():
    eval_dir = sys.argv[1]
    models = sys.argv[2:] or [os.path.basename(p) for p in glob.glob(os.path.join(eval_dir, "*")) if os.path.isdir(p)]
    print(f"{'model':10s} | {'turns/task':>10s} | {'search/task':>11s} | {'batch_factor':>12s} | {'%forloop':>8s} | {'%list_search':>12s} | n")
    print("-" * 82)
    for name in models:
        dirs = [p for p in glob.glob(os.path.join(eval_dir, name, "*")) if os.path.isdir(p)]
        rows = [r for r in (analyze_rollout(d) for d in dirs) if r]
        if not rows:
            print(f"{name:10s} | (no trajectories)")
            continue
        turns = mean(r["n_turns"] for r in rows)
        srch = mean(r["n_searches"] for r in rows)
        # batch factor per rollout (guard div0), then average
        bf = mean((r["n_searches"] / r["n_turns"]) if r["n_turns"] else 0 for r in rows)
        fl = mean(1.0 if r["forloop"] else 0.0 for r in rows)
        ls = mean(1.0 if r["list_search"] else 0.0 for r in rows)
        print(f"{name:10s} | {turns:10.1f} | {srch:11.1f} | {bf:12.2f} | {100*fl:7.0f}% | {100*ls:11.0f}% | {len(rows)}")


if __name__ == "__main__":
    main()
