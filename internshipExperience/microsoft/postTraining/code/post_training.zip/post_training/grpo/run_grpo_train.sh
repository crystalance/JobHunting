#!/usr/bin/env bash
# Scaled GRPO run for the WideSearch multi-turn tool agent (design Step 5b).
# Full train split (ws_en_001-070), periodic val (071-085 excl 079) vs the SFT
# baseline (val f1_item 0.345). Persistent-env agent loop + shared search cache.
#
# Run with the verl-multiturn-rollout env from the repo root:
#   bash post_training/grpo/run_grpo_train.sh
set -euo pipefail

REPO=/home/dkidna/WebSearchResearch
PY=/home/dkidna/miniconda3/envs/verl-multiturn-rollout/bin/python
cd "$REPO"

export WIDESEARCH_ROOT=/home/dkidna/WideSearch
export PYTHONPATH="$REPO:${PYTHONPATH:-}"
# Search throttle + budget + shared cache (dedup queries across the G rollouts of
# a group and across steps — the main cost saver at G=8).
export SEARCH_MAX_WORKERS=${SEARCH_MAX_WORKERS:-4}
export SEARCH_MAX_QUERIES_PER_CALL=${SEARCH_MAX_QUERIES_PER_CALL:-20}
export SEARCH_EPISODE_BUDGET=${SEARCH_EPISODE_BUDGET:-40}
export SEARCH_CACHE_DIR=${SEARCH_CACHE_DIR:-$REPO/post_training/grpo/search_cache}

DATA=post_training/grpo/data
ACTOR=post_training/grpo/actor_init_v2
TOOLS=post_training/grpo/tools.yaml
REWARD=post_training/grpo/widesearch_reward.py
AGENT_LOOP=post_training/grpo/agent_loop_config.yaml
CKPT=post_training/grpo/checkpoints/train_scaled

"$PY" -m verl.trainer.main_ppo \
  algorithm.adv_estimator=grpo \
  data.train_files="$DATA/train.parquet" \
  data.val_files="$DATA/val.parquet" \
  data.train_batch_size=8 \
  data.max_prompt_length=3072 \
  data.max_response_length=20480 \
  data.return_raw_chat=true \
  actor_rollout_ref.model.path="$ACTOR" \
  actor_rollout_ref.actor.strategy=fsdp2 \
  actor_rollout_ref.ref.strategy=fsdp2 \
  actor_rollout_ref.actor.optim.lr=1e-6 \
  actor_rollout_ref.actor.ppo_mini_batch_size=8 \
  actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=1 \
  actor_rollout_ref.rollout.name=sglang \
  actor_rollout_ref.rollout.mode=async \
  actor_rollout_ref.rollout.n=8 \
  actor_rollout_ref.rollout.gpu_memory_utilization=0.55 \
  actor_rollout_ref.rollout.tensor_model_parallel_size=1 \
  actor_rollout_ref.rollout.multi_turn.enable=true \
  actor_rollout_ref.rollout.multi_turn.format=hermes \
  actor_rollout_ref.rollout.multi_turn.max_assistant_turns=25 \
  actor_rollout_ref.rollout.multi_turn.max_tool_response_length=8192 \
  actor_rollout_ref.rollout.multi_turn.tool_config_path="$TOOLS" \
  actor_rollout_ref.rollout.agent.agent_loop_config_path="$AGENT_LOOP" \
  algorithm.kl_ctrl.kl_coef=0.001 \
  custom_reward_function.path="$REWARD" \
  custom_reward_function.name=compute_score \
  reward_model.launch_reward_fn_async=true \
  trainer.n_gpus_per_node=4 \
  trainer.nnodes=1 \
  trainer.total_epochs=100 \
  trainer.total_training_steps=30 \
  trainer.save_freq=5 \
  trainer.test_freq=5 \
  trainer.max_actor_ckpt_to_keep=2 \
  trainer.default_local_dir="$CKPT" \
  trainer.rollout_data_dir=post_training/grpo/rollout_dumps/train \
  trainer.validation_data_dir=post_training/grpo/rollout_dumps/val \
  trainer.project_name=widesearch_grpo \
  trainer.experiment_name=train_scaled \
  trainer.logger=console \
  "$@"
