"""LoRA SFT for the WideSearch code-act cold-start.

Consumes pre-tokenized JSONL produced by build_sft_data.py (each line has
`input_ids` and `labels`, where labels are -100 on masked context tokens and
real token-ids on assistant spans). Trains a LoRA adapter on
Qwen2.5-7B-Instruct so the student learns to DRIVE THE LOOP + emit valid
tool calls / code (the completion behavior it lacks).

Run (single GPU, e.g. GPU 1 while vLLM holds GPU 0):
  CUDA_VISIBLE_DEVICES=1 /home/dkidna/miniconda3/envs/new_verl/bin/python \
    post_training/sft/train_sft.py \
      --data post_training/sft/pilot_sft_loose.jsonl \
      --out  post_training/sft/ckpt_pilot --epochs 3
"""
from __future__ import annotations
import argparse
import json
import os

import torch
from torch.utils.data import Dataset
from transformers import (AutoModelForCausalLM, AutoTokenizer, Trainer,
                          TrainingArguments)
from peft import LoraConfig, get_peft_model

MODEL = "Qwen/Qwen2.5-7B-Instruct"
IGNORE = -100


class JsonlSFT(Dataset):
    def __init__(self, path, max_len):
        self.rows = []
        for line in open(path):
            line = line.strip()
            if not line:
                continue
            d = json.loads(line)
            ids, labels = d["input_ids"], d["labels"]
            if len(ids) > max_len:  # safety truncation (should already be filtered)
                ids, labels = ids[:max_len], labels[:max_len]
            self.rows.append((ids, labels))

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        ids, labels = self.rows[i]
        return {"input_ids": ids, "labels": labels}


class PadCollator:
    def __init__(self, pad_id):
        self.pad_id = pad_id

    def __call__(self, batch):
        maxlen = max(len(b["input_ids"]) for b in batch)
        input_ids, labels, attn = [], [], []
        for b in batch:
            ids, lab = b["input_ids"], b["labels"]
            pad = maxlen - len(ids)
            input_ids.append(ids + [self.pad_id] * pad)
            labels.append(lab + [IGNORE] * pad)
            attn.append([1] * len(ids) + [0] * pad)
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
            "attention_mask": torch.tensor(attn, dtype=torch.long),
        }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--epochs", type=float, default=3)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--max_len", type=int, default=28672)
    ap.add_argument("--lora_rank", type=int, default=32)
    ap.add_argument("--lora_alpha", type=int, default=64)
    ap.add_argument("--grad_accum", type=int, default=4)
    ap.add_argument("--save_epochs", action="store_true",
                    help="save a checkpoint every epoch (for val-completion gating)")
    args = ap.parse_args()

    tok = AutoTokenizer.from_pretrained(MODEL)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token

    ds = JsonlSFT(args.data, args.max_len)
    print(f"loaded {len(ds)} SFT examples from {args.data}")
    lens = [len(x[0]) for x in ds.rows]
    print(f"token lengths: min={min(lens)} max={max(lens)} mean={sum(lens)//len(lens)}")

    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, attn_implementation="flash_attention_2")
    model.config.use_cache = False
    model.gradient_checkpointing_enable()
    model.enable_input_require_grads()

    lora = LoraConfig(
        r=args.lora_rank, lora_alpha=args.lora_alpha, lora_dropout=0.05,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
        task_type="CAUSAL_LM",
    )
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()

    targs = TrainingArguments(
        output_dir=args.out,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=args.grad_accum,
        learning_rate=args.lr,
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
        bf16=True,
        logging_steps=1,
        save_strategy="epoch" if args.save_epochs else "no",
        report_to=[],
        gradient_checkpointing=True,
        remove_unused_columns=False,
    )

    trainer = Trainer(
        model=model, args=targs, train_dataset=ds,
        data_collator=PadCollator(tok.pad_token_id),
    )
    trainer.train()

    model.save_pretrained(args.out)
    tok.save_pretrained(args.out)
    print("saved LoRA adapter to", args.out)


if __name__ == "__main__":
    main()
