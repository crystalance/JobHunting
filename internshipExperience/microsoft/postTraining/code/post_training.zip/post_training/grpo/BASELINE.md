# SFT Baseline — frozen reference for GRPO comparison

This is the **cold-start SFT model** that GRPO is initialized from. It is the
fixed reference point for measuring GRPO's improvement. All artifacts below are
on local disk (git-ignored as weights) and are **not** overwritten by GRPO
(GRPO writes to `post_training/grpo/checkpoints/`).

## Artifacts (do not delete)
| What | Path | Size |
|------|------|------|
| SFT LoRA adapter (r32) | `post_training/sft/ckpt_train_v2/` | ~0.3G (+ checkpoints) |
| Merged full model (base + LoRA) = GRPO actor init | `post_training/grpo/actor_init_v2/` | ~15G |
| SFT training data (122 traj) | `post_training/sft/train_sft_v2.jsonl` | — |
| **Baseline val eval** (held-out ws_en_071–085) | `search_agent/batch_results/sft_v2_val/` | — |

## Baseline metrics (held-out val, 14 instances, ws_en_071–085 excl. 079)
Search = gpt-4.1-mini, SEARCH_EPISODE_BUDGET=80.

| Metric | Value |
|--------|-------|
| F1_item (mean) | **0.345** |
| F1_row (mean) | **0.176** |
| Output produced | **14 / 14** |
| Timeouts | **0** |
| score (strict) | 0.000 |

Progression that produced this baseline: base ~0.05 → LoRA-48 0.088 →
LoRA-48+prompt-fix 0.196 → **LoRA-122 (rejection-sampled) 0.345**.

## How to reproduce the baseline eval (for a fair GRPO comparison)
Serve the merged model (or the LoRA adapter) on vLLM and run the same val set
with the same settings:
```bash
# serve baseline (merged) on a free GPU
CUDA_VISIBLE_DEVICES=2 vllm serve post_training/grpo/actor_init_v2 \
  --served-model-name sft_baseline --max-model-len 32768 \
  --enable-auto-tool-choice --tool-call-parser hermes --port 8002
# eval (harness venv)
VAL=$(python3 -c "print(','.join('ws_en_%03d'%i for i in list(range(71,79))+list(range(80,86))))")
SEARCH_MAX_WORKERS=8 SEARCH_EPISODE_BUDGET=80 .venv-harness/bin/python -m search_agent.batch_eval \
  --instance_ids "$VAL" --stage both --widesearch_root /home/dkidna/WideSearch \
  --reasoning_model sft_baseline --reasoning_base_url http://localhost:8002/v1 \
  --search_model gpt-4.1-mini --prompt_variant base --max_iterations 25 --timeout 900 \
  --output_root search_agent/batch_results/sft_baseline_val
```
GRPO checkpoints are evaluated the same way; compare F1_item / F1_row / output-rate
against the table above.
